# Aurora Wallet (demonstração)

Simulador de carteira cripto para Android (Kotlin + Jetpack Compose).
Preços reais (CoinGecko, API pública sem chave) com saldo 100% fictício.

Recursos: mercado com busca/filtros/favoritos, gráfico (24h/7d/30d/1a), compra e venda fictícias
com % e Máx, posição com lucro/prejuízo, histórico, distribuição em gráfico de pizza, USD/BRL,
alertas de preço (notificação em segundo plano), enviar/receber simulados, PIN + digital,
tema claro/escuro.

Build: abra no Android Studio ou use o workflow do GitHub Actions (gradle assembleDebug).
