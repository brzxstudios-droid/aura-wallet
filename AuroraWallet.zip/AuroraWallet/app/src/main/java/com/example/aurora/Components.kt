package com.example.aurora

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.ui.draw.scale
import kotlinx.coroutines.delay
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlin.math.roundToInt

@Composable
fun pieColors(): List<Color> = listOf(
    Accent, Color(0xFFFFB020), Color(0xFF4DA3FF), Color(0xFFFF6B9A), Color(0xFF9CA3AF), Color(0xFF3DDC97)
)

// Entrada suave (fade + subida). Só anima na abertura da tela, nunca ao rolar a lista.
@Composable
fun Appear(index: Int, animate: Boolean = true, content: @Composable () -> Unit) {
    var shown by remember { mutableStateOf(!animate) }
    if (animate) {
        LaunchedEffect(Unit) {
            delay(index * 70L)
            shown = true
        }
    }
    AnimatedVisibility(
        visible = shown,
        enter = fadeIn(tween(450)) + slideInVertically(tween(450)) { it / 4 }
    ) { content() }
}

@Composable
fun RoundIconButton(icon: ImageVector, desc: String, onClick: () -> Unit) {
    Box(
        Modifier.size(44.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surface).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) { Icon(icon, desc, modifier = Modifier.size(22.dp)) }
}

@Composable
fun CoinLogo(url: String, size: Dp = 40.dp) {
    AsyncImage(
        model = url, contentDescription = null,
        modifier = Modifier.size(size).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant)
    )
}

@Composable
fun TopBar(title: String, onBack: () -> Unit, actions: @Composable RowScope.() -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar") }
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        actions()
    }
}

@Composable
fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surface).padding(16.dp),
        content = content
    )
}

@Composable
fun ActionButton(
    icon: ImageVector, label: String, modifier: Modifier = Modifier,
    primary: Boolean = false, onClick: () -> Unit
) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(
        if (pressed) 0.9f else 1f, spring(dampingRatio = 0.5f, stiffness = 500f), label = "press"
    )
    val accent = Accent
    val bg = if (primary) Brush.verticalGradient(listOf(accent, accent.copy(alpha = 0.72f)))
    else Brush.verticalGradient(listOf(accent.copy(alpha = 0.22f), accent.copy(alpha = 0.07f)))
    Column(
        modifier.scale(scale).clickable(interactionSource = src, indication = null) { onClick() },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.size(64.dp).clip(RoundedCornerShape(22.dp)).background(bg)
                .border(1.dp, accent.copy(alpha = if (primary) 0f else 0.3f), RoundedCornerShape(22.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, label, tint = if (primary) MaterialTheme.colorScheme.onPrimary else accent, modifier = Modifier.size(28.dp))
        }
        Spacer(Modifier.height(8.dp))
        Text(label, color = MaterialTheme.colorScheme.onBackground, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun LineChart(values: List<Double>, modifier: Modifier = Modifier, onSelect: (Int?) -> Unit = {}) {
    if (values.size < 2) return
    val color = if (values.last() >= values.first()) Positive else Negative
    val min = values.minOrNull() ?: 0.0
    val max = values.maxOrNull() ?: 1.0
    var sel by remember(values) { mutableStateOf<Int?>(null) }
    fun idxAt(x: Float, w: Int): Int =
        ((x / w.coerceAtLeast(1)) * (values.size - 1)).roundToInt().coerceIn(0, values.size - 1)

    Canvas(
        modifier.pointerInput(values) {
            detectHorizontalDragGestures(
                onDragStart = { o -> val i = idxAt(o.x, size.width); sel = i; onSelect(i) },
                onDragEnd = { sel = null; onSelect(null) },
                onDragCancel = { sel = null; onSelect(null) },
                onHorizontalDrag = { change, _ -> val i = idxAt(change.position.x, size.width); sel = i; onSelect(i) }
            )
        }
    ) {
        val w = size.width
        val h = size.height
        val range = if (max - min > 0) max - min else 1.0
        fun px(i: Int): Float = w * i / (values.size - 1)
        fun py(v: Double): Float = (h - ((v - min) / range * h * 0.9 + h * 0.05)).toFloat()
        val line = Path()
        val fill = Path()
        fill.moveTo(px(0), h)
        values.forEachIndexed { i, v ->
            if (i == 0) line.moveTo(px(i), py(v)) else line.lineTo(px(i), py(v))
            fill.lineTo(px(i), py(v))
        }
        fill.lineTo(w, h)
        fill.close()
        drawPath(fill, Brush.verticalGradient(listOf(color.copy(alpha = 0.28f), Color.Transparent)))
        drawPath(line, color, style = Stroke(width = 4f, cap = StrokeCap.Round))
        sel?.let { i ->
            drawLine(color.copy(alpha = 0.6f), Offset(px(i), 0f), Offset(px(i), h), strokeWidth = 2f)
            drawCircle(color, 10f, Offset(px(i), py(values[i])))
        }
    }
}

@Composable
fun PieChart(values: List<Float>, modifier: Modifier = Modifier, progress: Float = 1f) {
    val total = values.sum()
    val colors = pieColors()
    Canvas(modifier) {
        if (total <= 0f) return@Canvas
        val stroke = size.minDimension * 0.22f
        val d = size.minDimension - stroke
        var start = -90f
        values.forEachIndexed { i, v ->
            val sweep = v / total * 360f * progress
            drawArc(
                colors[i % colors.size], start, (sweep - 1.5f).coerceAtLeast(0f), false,
                topLeft = Offset(stroke / 2, stroke / 2), size = Size(d, d), style = Stroke(stroke)
            )
            start += sweep
        }
    }
}

// QR ilustrativo (não é um QR code real), gerado a partir do endereço.
@Composable
fun FakeQr(seed: String, modifier: Modifier = Modifier) {
    val n = 25
    val rnd = java.util.Random(seed.hashCode().toLong())
    val cells = remember(seed) { Array(n) { BooleanArray(n) { rnd.nextBoolean() } } }
    Canvas(modifier.background(Color.White)) {
        val cs = size.width / n
        fun finder(ox: Int, oy: Int) {
            for (y in 0 until 7) for (x in 0 until 7) {
                val edge = x == 0 || y == 0 || x == 6 || y == 6
                val core = x in 2..4 && y in 2..4
                cells[oy + y][ox + x] = edge || core
            }
            for (k in -1..7) {
                for ((a, b) in listOf(ox + k to oy - 1, ox + k to oy + 7, ox - 1 to oy + k, ox + 7 to oy + k)) {
                    if (a in 0 until n && b in 0 until n) cells[b][a] = false
                }
            }
        }
        finder(0, 0); finder(n - 7, 0); finder(0, n - 7)
        for (y in 0 until n) for (x in 0 until n) {
            if (cells[y][x]) drawRect(Color.Black, Offset(x * cs, y * cs), Size(cs + 0.5f, cs + 0.5f))
        }
    }
}
