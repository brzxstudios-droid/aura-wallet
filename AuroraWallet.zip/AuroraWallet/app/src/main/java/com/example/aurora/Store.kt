package com.example.aurora

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class Store(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("aurora", Context.MODE_PRIVATE)

    private fun d(k: String, def: Double): Double = sp.getString(k, null)?.toDoubleOrNull() ?: def
    private fun putD(k: String, v: Double) { sp.edit().putString(k, v.toString()).apply() }

    var cash: Double
        get() = d("cash", START_CASH)
        set(v) = putD("cash", v)
    var rate: Double
        get() = d("rate", 5.5)
        set(v) = putD("rate", v)
    var currency: String
        get() = sp.getString("currency", "USD") ?: "USD"
        set(v) { sp.edit().putString("currency", v).apply() }
    var theme: Int
        get() = sp.getInt("theme", 0)
        set(v) { sp.edit().putInt("theme", v).apply() }
    var accent: Int
        get() = sp.getInt("accent", 0)
        set(v) { sp.edit().putInt("accent", v).apply() }
    var gradient: Boolean
        get() = sp.getBoolean("grad", true)
        set(v) { sp.edit().putBoolean("grad", v).apply() }
    var hideBalance: Boolean
        get() = sp.getBoolean("hide", false)
        set(v) { sp.edit().putBoolean("hide", v).apply() }
    var userName: String
        get() = sp.getString("uname", "") ?: ""
        set(v) { sp.edit().putString("uname", v).apply() }
    var since: Long?
        get() = if (sp.contains("since")) sp.getLong("since", 0L) else null
        set(v) { if (v != null) sp.edit().putLong("since", v).apply() }
    var pinHash: String?
        get() = sp.getString("pin", null)
        set(v) { if (v == null) sp.edit().remove("pin").apply() else sp.edit().putString("pin", v).apply() }
    var biometric: Boolean
        get() = sp.getBoolean("bio", false)
        set(v) { sp.edit().putBoolean("bio", v).apply() }
    var address: String?
        get() = sp.getString("addr", null)
        set(v) { sp.edit().putString("addr", v).apply() }
    var favorites: Set<String>
        get() = sp.getStringSet("fav", emptySet())?.toSet() ?: emptySet()
        set(v) { sp.edit().putStringSet("fav", HashSet(v)).apply() }

    private fun <T> parse(key: String, f: (JSONObject) -> T): List<T> {
        val s = sp.getString(key, null) ?: return emptyList()
        return try {
            val a = JSONArray(s)
            (0 until a.length()).map { f(a.getJSONObject(it)) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun <T> save(key: String, list: List<T>, f: (T) -> JSONObject) {
        val a = JSONArray()
        list.forEach { a.put(f(it)) }
        sp.edit().putString(key, a.toString()).apply()
    }

    fun loadCoins(): List<Coin> = parse("coins") {
        Coin(it.getString("id"), it.getString("s"), it.getString("n"), it.getString("i"),
            it.getDouble("p"), it.getDouble("c"), it.getDouble("m"))
    }
    fun saveCoins(l: List<Coin>) = save("coins", l) {
        JSONObject().put("id", it.id).put("s", it.symbol).put("n", it.name).put("i", it.image)
            .put("p", it.price.safe()).put("c", it.change24h.safe()).put("m", it.marketCap.safe())
    }

    fun loadHoldings(): List<Holding> = parse("holdings") {
        Holding(it.getString("id"), it.getString("s"), it.getString("n"), it.getString("i"),
            it.getDouble("q"), it.getDouble("c"))
    }
    fun saveHoldings(l: List<Holding>) = save("holdings", l) {
        JSONObject().put("id", it.coinId).put("s", it.symbol).put("n", it.name).put("i", it.image)
            .put("q", it.qty.safe()).put("c", it.costUsd.safe())
    }

    fun loadTxs(): List<Tx> = parse("txs") {
        Tx(it.getLong("t"), it.getString("y"), it.getString("id"), it.getString("s"),
            it.getDouble("q"), it.getDouble("p"))
    }
    fun saveTxs(l: List<Tx>) = save("txs", l.take(500)) {
        JSONObject().put("t", it.time).put("y", it.type).put("id", it.coinId).put("s", it.symbol)
            .put("q", it.qty.safe()).put("p", it.priceUsd.safe())
    }

    fun loadAlerts(): List<PriceAlert> = parse("alerts") {
        PriceAlert(it.getLong("id"), it.getString("c"), it.getString("s"), it.getDouble("t"), it.getBoolean("a"))
    }
    fun saveAlerts(l: List<PriceAlert>) = save("alerts", l) {
        JSONObject().put("id", it.id).put("c", it.coinId).put("s", it.symbol)
            .put("t", it.target).put("a", it.above)
    }
}
