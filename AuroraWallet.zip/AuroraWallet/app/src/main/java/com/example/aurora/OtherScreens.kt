package com.example.aurora

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.filled.Check
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

@Composable
fun SendScreen(vm: AppViewModel) {
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    var selId by remember { mutableStateOf(vm.holdings.firstOrNull()?.coinId) }
    var addr by remember { mutableStateOf("") }
    var qty by remember { mutableStateOf("") }
    var dest by remember { mutableStateOf("") }
    val h = vm.holdings.find { it.coinId == selId }
    Column(Modifier.fillMaxSize()) {
        TopBar("Enviar", onBack = { vm.pop() })
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Envio simulado: nada sai de verdade, só a quantidade fictícia diminui.", color = muted, fontSize = 13.sp)
            if (vm.holdings.isEmpty() || h == null) {
                Text("Você não tem ativos para enviar. Compre algo no Mercado primeiro.")
            } else {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    vm.holdings.forEach {
                        FilterChip(selected = selId == it.coinId, onClick = { selId = it.coinId }, label = { Text(it.symbol) })
                    }
                }
                Text("Disponível: " + qtyFmt(h.qty) + " " + h.symbol, color = muted)
                OutlinedTextField(
                    value = addr, onValueChange = { addr = it }, singleLine = true,
                    modifier = Modifier.fillMaxWidth(), label = { Text("Endereço de destino (0x...)") }
                )
                OutlinedTextField(
                    value = dest, onValueChange = { if (it.length <= 30) dest = it }, singleLine = true,
                    modifier = Modifier.fillMaxWidth(), label = { Text("Nome do destino (opcional)") }
                )
                if (vm.destinations.isNotEmpty()) {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        vm.destinations.forEach { n ->
                            FilterChip(selected = dest == n, onClick = { dest = n }, label = { Text(n) })
                        }
                    }
                }
                OutlinedTextField(
                    value = qty, onValueChange = { qty = it }, singleLine = true,
                    modifier = Modifier.fillMaxWidth(), label = { Text("Quantidade de " + h.symbol) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
                OutlinedButton(onClick = { qty = qtyFmt(h.qty) }) { Text("Máx") }
                Button(
                    onClick = {
                        val q = qty.replace(',', '.').toDoubleOrNull() ?: 0.0
                        if (vm.send(h, q, addr, dest)) vm.pop()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Enviar (demonstração)") }
            }
        }
    }
}

@Composable
fun ReceiveScreen(vm: AppViewModel) {
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val clip = LocalClipboardManager.current
    Column(Modifier.fillMaxSize()) {
        TopBar("Receber", onBack = { vm.pop() })
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            FakeQr(vm.address, Modifier.size(220.dp).clip(RoundedCornerShape(12.dp)).padding(8.dp))
            Text("QR ilustrativo — não é um QR code real.", color = muted, fontSize = 12.sp)
            Panel {
                Text("Seu endereço fictício", color = muted, fontSize = 13.sp)
                Text(vm.address, fontSize = 14.sp)
            }
            Button(onClick = {
                clip.setText(AnnotatedString(vm.address))
                vm.message = "Endereço copiado."
            }) { Text("Copiar endereço") }
            Text("Este endereço é só de demonstração. Não envie criptomoedas reais para ele.", color = Negative, fontSize = 12.sp)
        }
    }
}

@Composable
fun HistoryScreen(vm: AppViewModel) {
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(16.dp))
        Text("Histórico", fontWeight = FontWeight.Bold, fontSize = 22.sp)
        Spacer(Modifier.height(8.dp))
        if (vm.txs.isEmpty()) {
            Text("Nenhuma transação ainda.", color = muted)
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(vm.txs) { t ->
                    val label = when (t.type) { "BUY" -> "Compra"; "SELL" -> "Venda"; "DEPOSIT" -> "Depósito"; else -> "Envio" }
                    val color = when (t.type) { "BUY" -> Positive; "SELL" -> Negative; "DEPOSIT" -> Positive; else -> Accent }
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                            .background(MaterialTheme.colorScheme.surface).padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(if (t.type == "DEPOSIT") label else label + " " + t.symbol, color = color, fontWeight = FontWeight.Medium)
                            Text(dateFmt(t.time), color = muted, fontSize = 12.sp)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            if (t.type == "DEPOSIT") {
                                Text(vm.money(t.qty, true), color = Positive)
                            } else {
                                Text(qtyFmt(t.qty) + " " + t.symbol)
                                Text("a " + vm.money(t.priceUsd), color = muted, fontSize = 12.sp)
                            }
                        }
                    }
                }
                item { Spacer(Modifier.height(16.dp)) }
            }
        }
    }
}

@Composable
fun AlertsScreen(vm: AppViewModel) {
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    LaunchedEffect(Unit) { vm.refresh() }
    Column(Modifier.fillMaxSize()) {
        TopBar("Alertas de preço", onBack = { vm.pop() })
        Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Crie alertas na tela de cada moeda (ícone de sino). Eles são checados em segundo plano e removidos ao disparar.",
                color = muted, fontSize = 13.sp)
            if (vm.alerts.isEmpty()) Text("Nenhum alerta ativo.", color = muted)
            vm.alerts.forEach { a ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.surface).padding(start = 16.dp, top = 4.dp, bottom = 4.dp, end = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        a.symbol + (if (a.above) " acima de US$ " else " abaixo de US$ ") + String.format(Locale.US, "%,.2f", a.target),
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { vm.removeAlert(a.id) }) { Icon(Icons.Filled.Delete, "Remover") }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: AppViewModel) {
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    var pinDialog by remember { mutableStateOf(false) }
    var resetDialog by remember { mutableStateOf(false) }
    var addDialog by remember { mutableStateOf(false) }
    var initDialog by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
    TopBar("Ajustes", onBack = { vm.pop() })
    LazyColumn(Modifier.weight(1f).padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Panel {
                Text("Moeda de exibição", fontWeight = FontWeight.SemiBold)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = vm.currency == "USD", onClick = { vm.updateCurrency("USD") }, label = { Text("Dólar (US$)") })
                    FilterChip(selected = vm.currency == "BRL", onClick = { vm.updateCurrency("BRL") }, label = { Text("Real (R$)") })
                    FilterChip(selected = vm.currency == "BTC", onClick = { vm.updateCurrency("BTC") }, label = { Text("Bitcoin (₿)") })
                }
                if (vm.currency == "BTC") {
                    Text("Seu saldo e os preços passam a aparecer em Bitcoin. ₿ 1 = US$ " + String.format(Locale.US, "%,.2f", vm.price("bitcoin")), color = muted, fontSize = 12.sp)
                }
                if (vm.currency == "BRL") Text("US$ 1 = R$ " + String.format(Locale.US, "%.2f", vm.usdBrl), color = muted, fontSize = 12.sp)
            }
        }
        item {
            Panel {
                Text("Tema", fontWeight = FontWeight.SemiBold)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0 to "Sistema", 1 to "Escuro", 2 to "Claro", 3 to "Preto").forEach { (v, t) ->
                        FilterChip(selected = vm.theme == v, onClick = { vm.updateTheme(v) }, label = { Text(t) })
                    }
                }
                if (vm.theme == 3) Text("Fundo preto total, ideal para telas AMOLED.", color = muted, fontSize = 12.sp)
                Spacer(Modifier.height(12.dp))
                Text("Cor de destaque", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    AccentOptions.forEachIndexed { i, (label, color) ->
                        AccentDot(color, label, vm.accent == i) { vm.updateAccent(i) }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Gradiente animado no saldo")
                        Text("Brilho em movimento atrás do saldo total.", color = muted, fontSize = 12.sp)
                    }
                    Switch(checked = vm.gradient, onCheckedChange = { vm.updateGradient(it) })
                }
            }
        }
        item {
            val installed = remember { vm.notifierInstalled() }
            Panel {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Avisar no Aurora Avisos", fontWeight = FontWeight.SemiBold)
                        Text(
                            if (installed) "App Aurora Avisos encontrado." else "Aurora Avisos não encontrado. Instale e abra uma vez.",
                            color = muted, fontSize = 12.sp
                        )
                    }
                    Switch(checked = vm.notifyOn, onCheckedChange = { vm.updateNotify(it) })
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { vm.sendTestNotification() }) { Text("Enviar aviso de teste") }
            }
        }
        item {
            Panel {
                Text("Segurança", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(if (vm.hasPin) "PIN ativado" else "PIN desativado", modifier = Modifier.weight(1f))
                    if (vm.hasPin) TextButton(onClick = { vm.setPin(null) }) { Text("Remover") }
                    TextButton(onClick = { pinDialog = true }) { Text(if (vm.hasPin) "Alterar" else "Definir") }
                }
                if (vm.hasPin) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Desbloquear com digital", modifier = Modifier.weight(1f))
                        Switch(checked = vm.biometric, onCheckedChange = { vm.updateBiometric(it) })
                    }
                }
            }
        }
        item {
            Panel {
                Text("Demonstração", fontWeight = FontWeight.SemiBold)
                Text("Saldo inicial: " + vm.money(vm.startCash), color = muted, fontSize = 13.sp)
                Text("Total depositado: " + vm.money(vm.capital), color = muted, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { vm.push(Route.Alerts) }) { Text("Ver alertas de preço") }
                OutlinedButton(onClick = { addDialog = true }) { Text("Adicionar saldo") }
                OutlinedButton(onClick = { initDialog = true }) { Text("Definir saldo inicial") }
                OutlinedButton(onClick = { resetDialog = true }) { Text("Reiniciar demonstração") }
            }
        }
        item {
            Text(
                "Aurora Wallet 0.2.0 · simulador educacional. Preços reais via CoinGecko; nenhuma carteira ou dinheiro real é usado.",
                color = muted, fontSize = 12.sp
            )
            Spacer(Modifier.height(24.dp))
        }
    }
    }

    if (pinDialog) {
        var p by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { pinDialog = false },
            title = { Text("Definir PIN") },
            text = {
                OutlinedTextField(
                    value = p, onValueChange = { if (it.length <= 8 && it.all { c -> c.isDigit() }) p = it },
                    singleLine = true, label = { Text("4 a 8 dígitos") },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
                )
            },
            confirmButton = {
                TextButton(enabled = p.length >= 4, onClick = { vm.setPin(p); pinDialog = false; vm.message = "PIN salvo." }) { Text("Salvar") }
            },
            dismissButton = { TextButton(onClick = { pinDialog = false }) { Text("Cancelar") } }
        )
    }
    if (addDialog) AddBalanceDialog(vm) { addDialog = false }
    if (initDialog) InitialBalanceDialog(vm) { initDialog = false }
    if (resetDialog) {
        AlertDialog(
            onDismissRequest = { resetDialog = false },
            title = { Text("Reiniciar demonstração?") },
            text = { Text("O saldo volta para o valor inicial e ativos e histórico são apagados.") },
            confirmButton = { TextButton(onClick = { vm.resetDemo(); resetDialog = false }) { Text("Reiniciar") } },
            dismissButton = { TextButton(onClick = { resetDialog = false }) { Text("Cancelar") } }
        )
    }
}

@Composable
fun AccentDot(color: Color, label: String, selected: Boolean, onClick: () -> Unit) {
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { onClick() }.padding(4.dp)) {
        Box(
            Modifier.size(40.dp).clip(CircleShape).background(color).border(
                if (selected) 3.dp else 1.dp,
                if (selected) MaterialTheme.colorScheme.onBackground else muted.copy(alpha = 0.4f),
                CircleShape
            ),
            contentAlignment = Alignment.Center
        ) {
            if (selected) Icon(
                Icons.Filled.Check, null,
                tint = if (color.luminance() > 0.5f) Color.Black else Color.White,
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(Modifier.height(2.dp))
        Text(label, fontSize = 11.sp, color = muted)
    }
}

@Composable
fun AddBalanceDialog(vm: AppViewModel, onDismiss: () -> Unit) {
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    var text by remember { mutableStateOf("") }
    val v = text.replace(',', '.').toDoubleOrNull() ?: 0.0
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Adicionar saldo") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = text, onValueChange = { text = it }, singleLine = true,
                    label = { Text("Valor em " + vm.currencySymbol()) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
                Text("Entra como depósito no histórico e não conta como lucro.", color = muted, fontSize = 12.sp)
                if (v > 0) Text("Novo saldo disponível: " + vm.money(vm.cash + vm.toUsd(v)), fontSize = 13.sp)
            }
        },
        confirmButton = {
            TextButton(enabled = v > 0, onClick = { if (vm.deposit(vm.toUsd(v))) onDismiss() }) { Text("Adicionar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
fun InitialBalanceDialog(vm: AppViewModel, onDismiss: () -> Unit) {
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    var text by remember { mutableStateOf("") }
    val v = text.replace(',', '.').toDoubleOrNull() ?: 0.0
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Definir saldo inicial") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = text, onValueChange = { text = it }, singleLine = true,
                    label = { Text("Saldo inicial em " + vm.currencySymbol()) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
                Text(
                    "Atenção: isso apaga seus ativos e o histórico e recomeça a demonstração com esse saldo. O lucro e o gráfico passam a contar a partir dele.",
                    color = muted, fontSize = 12.sp
                )
            }
        },
        confirmButton = {
            TextButton(enabled = v > 0, onClick = { if (vm.setInitialBalance(vm.toUsd(v))) onDismiss() }) { Text("Definir") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
