package com.example.aurora

// Dados fictícios apenas para demonstração. Nenhuma funcionalidade de carteira real.
data class Asset(val symbol: String, val name: String, val amount: String, val value: Double, val change: Double)

val demoAssets = listOf(
    Asset("AUR", "Aurora Coin", "1.250", 3125.50, 2.4),
    Asset("STL", "Stellar Demo", "420", 840.00, -1.1),
    Asset("NVA", "Nova Token", "9.800", 612.30, 0.6),
    Asset("LMN", "Lumen Demo", "75", 198.75, -3.2),
)
