package com.example.aurora

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun MiniStat(label: String, value: String, modifier: Modifier = Modifier, color: Color = Color.Unspecified) {
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    Column(modifier) {
        Text(label, color = muted, fontSize = 11.sp)
        Text(value, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = color, maxLines = 1)
    }
}

// ---------------------------------------------------------------- Carteira
@Composable
fun WalletScreen(vm: AppViewModel) {
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val clip = LocalClipboardManager.current
    val total = vm.totalValue()
    val invested = vm.holdingsValue()
    val pl = total - START_CASH
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Spacer(Modifier.height(16.dp))
            Text("Carteira", fontWeight = FontWeight.Bold, fontSize = 22.sp)
            Spacer(Modifier.height(8.dp))
            Text("Patrimônio total", color = muted, fontSize = 13.sp)
            Text(vm.moneyH(total), fontSize = 34.sp, fontWeight = FontWeight.Bold)
            Text(
                if (vm.hideBalance) "••••••" else vm.money(pl, true) + " (" + pctFmt(pl / START_CASH * 100) + ") desde o início",
                color = plColor(pl), fontSize = 13.sp
            )
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Panel(Modifier.weight(1f)) {
                    Text("Disponível", color = muted, fontSize = 12.sp)
                    Text(vm.moneyH(vm.cash), fontWeight = FontWeight.SemiBold, fontSize = 17.sp, maxLines = 1)
                }
                Panel(Modifier.weight(1f)) {
                    Text("Em ativos", color = muted, fontSize = 12.sp)
                    Text(vm.moneyH(invested), fontWeight = FontWeight.SemiBold, fontSize = 17.sp, maxLines = 1)
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth()) {
                ActionButton(Icons.Filled.ArrowUpward, "Enviar", Modifier.weight(1f)) { vm.push(Route.Send) }
                ActionButton(Icons.Filled.ArrowDownward, "Receber", Modifier.weight(1f)) { vm.push(Route.Receive) }
                ActionButton(Icons.Filled.Add, "Comprar", Modifier.weight(1f), primary = true) { vm.tab = 1 }
            }
        }
        item { Text("Meus ativos (" + vm.holdings.size + ")", fontSize = 18.sp, fontWeight = FontWeight.SemiBold) }
        if (vm.holdings.isEmpty()) {
            item { Text("Nenhum ativo ainda. Compre uma moeda na aba Mercado.", color = muted) }
        }
        items(vm.holdings, key = { it.coinId }) { h ->
            val value = vm.holdingValue(h)
            val cost = h.costUsd
            val hpl = value - cost
            val pct = if (cost > 0) hpl / cost * 100 else 0.0
            val price = vm.price(h.coinId)
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable { vm.openCoin(h.coinId) }
                    .background(MaterialTheme.colorScheme.surface).padding(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CoinLogo(h.image, 40.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(h.name, fontWeight = FontWeight.SemiBold, maxLines = 1)
                        Text(qtyFmt(h.qty) + " " + h.symbol, color = muted, fontSize = 13.sp, maxLines = 1)
                    }
                    Text(vm.moneyH(value), fontWeight = FontWeight.SemiBold)
                }
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth()) {
                    MiniStat("Preço atual", vm.money(price), Modifier.weight(1f))
                    MiniStat("Preço médio", vm.money(if (h.qty > 0) cost / h.qty else 0.0), Modifier.weight(1f))
                    MiniStat(
                        "Lucro / prejuízo",
                        if (vm.hideBalance) "••••" else vm.money(hpl, true) + " (" + pctFmt(pct) + ")",
                        Modifier.weight(1.4f), plColor(hpl)
                    )
                }
            }
        }
        item {
            Panel {
                Text("Meu endereço (demonstração)", color = muted, fontSize = 12.sp)
                Spacer(Modifier.height(4.dp))
                Text(vm.address, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = {
                    clip.setText(AnnotatedString(vm.address))
                    vm.message = "Endereço copiado."
                }) { Text("Copiar endereço") }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

// ---------------------------------------------------------------- Perfil
@Composable
fun MenuRow(icon: ImageVector, title: String, subtitle: String? = null, color: Color = Color.Unspecified, onClick: () -> Unit) {
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    Row(
        Modifier.fillMaxWidth().clickable { onClick() }.padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = if (color == Color.Unspecified) Accent else color, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = color)
            if (subtitle != null) Text(subtitle, color = muted, fontSize = 12.sp)
        }
        Icon(Icons.Filled.ChevronRight, null, tint = muted)
    }
}

@Composable
fun ProfileScreen(vm: AppViewModel) {
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val accent = Accent
    val total = vm.totalValue()
    val pl = total - START_CASH
    var nameDialog by remember { mutableStateOf(false) }
    var resetDialog by remember { mutableStateOf(false) }

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Spacer(Modifier.height(16.dp))
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    Modifier.size(88.dp).clip(CircleShape)
                        .background(Brush.linearGradient(listOf(accent, accent.copy(alpha = 0.35f)))),
                    contentAlignment = Alignment.Center
                ) {
                    val initial = vm.userName.firstOrNull()?.uppercase()
                    if (initial != null) {
                        Text(initial, fontSize = 36.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimary)
                    } else {
                        Icon(Icons.Filled.Person, null, tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(44.dp))
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(
                    Modifier.clip(RoundedCornerShape(50)).clickable { nameDialog = true }.padding(horizontal = 12.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        if (vm.userName.isBlank()) "Definir meu nome" else vm.userName,
                        fontSize = 20.sp, fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.width(6.dp))
                    Icon(Icons.Filled.Edit, "Editar nome", tint = muted, modifier = Modifier.size(16.dp))
                }
                Text("Conta de demonstração desde " + dateOnly(vm.since), color = muted, fontSize = 13.sp)
            }
        }
        item {
            Panel {
                Row(Modifier.fillMaxWidth()) {
                    MiniStat("Patrimônio", vm.moneyH(total), Modifier.weight(1f))
                    MiniStat(
                        "Retorno",
                        if (vm.hideBalance) "••••" else pctFmt(pl / START_CASH * 100),
                        Modifier.weight(1f), plColor(pl)
                    )
                }
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth()) {
                    MiniStat("Transações", vm.txs.size.toString(), Modifier.weight(1f))
                    MiniStat("Ativos", vm.holdings.size.toString(), Modifier.weight(1f))
                }
            }
        }
        item {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surface)) {
                MenuRow(Icons.Filled.Settings, "Ajustes e aparência", "Moeda, tema, cor, gradiente e segurança") { vm.push(Route.Settings) }
                MenuRow(
                    Icons.Filled.NotificationsActive, "Alertas de preço",
                    if (vm.alerts.isEmpty()) "Nenhum alerta ativo" else vm.alerts.size.toString() + " ativo(s)"
                ) { vm.push(Route.Alerts) }
                MenuRow(Icons.Filled.ArrowDownward, "Receber") { vm.push(Route.Receive) }
                MenuRow(Icons.Filled.ArrowUpward, "Enviar") { vm.push(Route.Send) }
                MenuRow(Icons.Filled.RestartAlt, "Reiniciar demonstração", color = Negative) { resetDialog = true }
            }
        }
        item {
            Text(
                "Aurora Wallet 0.3.0 · simulador educacional. Preços reais via Binance e CoinGecko; nenhum dinheiro real é usado.",
                color = muted, fontSize = 12.sp
            )
            Spacer(Modifier.height(24.dp))
        }
    }

    if (nameDialog) {
        var n by remember { mutableStateOf(vm.userName) }
        AlertDialog(
            onDismissRequest = { nameDialog = false },
            title = { Text("Seu nome") },
            text = {
                OutlinedTextField(
                    value = n, onValueChange = { if (it.length <= 30) n = it }, singleLine = true,
                    label = { Text("Nome") }
                )
            },
            confirmButton = { TextButton(onClick = { vm.updateName(n); nameDialog = false }) { Text("Salvar") } },
            dismissButton = { TextButton(onClick = { nameDialog = false }) { Text("Cancelar") } }
        )
    }
    if (resetDialog) {
        AlertDialog(
            onDismissRequest = { resetDialog = false },
            title = { Text("Reiniciar demonstração?") },
            text = { Text("O saldo volta para o valor inicial e ativos e histórico são apagados.") },
            confirmButton = { TextButton(onClick = { vm.resetDemo(); resetDialog = false }) { Text("Reiniciar") } },
            dismissButton = { TextButton(onClick = { resetDialog = false }) { Text("Cancelar") } }
        )
    }
}
