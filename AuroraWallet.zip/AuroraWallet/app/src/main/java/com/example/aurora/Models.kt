package com.example.aurora

import java.math.BigDecimal
import java.math.RoundingMode
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

const val START_CASH = 10000.0

data class Coin(
    val id: String, val symbol: String, val name: String, val image: String,
    val price: Double, val change24h: Double, val marketCap: Double
)

data class Holding(
    val coinId: String, val symbol: String, val name: String, val image: String,
    val qty: Double, val costUsd: Double
)

// type: BUY, SELL, SEND
data class Tx(val time: Long, val type: String, val coinId: String, val symbol: String, val qty: Double, val priceUsd: Double)

data class PriceAlert(val id: Long, val coinId: String, val symbol: String, val target: Double, val above: Boolean)

data class RangeCfg(val label: String, val interval: String, val limit: Int, val spanMs: Long, val days: Int)

val Ranges = listOf(
    RangeCfg("1D", "15m", 96, 86_400_000L, 1),
    RangeCfg("1S", "1h", 168, 604_800_000L, 7),
    RangeCfg("1M", "4h", 180, 2_592_000_000L, 30),
    RangeCfg("3M", "1d", 90, 7_776_000_000L, 90),
    RangeCfg("1A", "1d", 365, 31_536_000_000L, 365)
)

sealed interface Route {
    data class Detail(val id: String) : Route
    object Send : Route
    object Receive : Route
    object Alerts : Route
    object Settings : Route
}

fun Double.safe(): Double = if (isNaN() || isInfinite()) 0.0 else this

fun qtyFmt(q: Double): String =
    BigDecimal(q.safe()).setScale(8, RoundingMode.HALF_UP).stripTrailingZeros().toPlainString()

fun pctFmt(p: Double): String =
    (if (p >= 0) "+" else "") + String.format(Locale.US, "%.2f", p.safe()) + "%"

fun dateFmt(t: Long): String =
    SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR")).format(Date(t))

fun dateOnly(t: Long): String =
    SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR")).format(Date(t))
