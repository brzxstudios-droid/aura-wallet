package com.example.aurora

import java.math.BigDecimal
import java.math.RoundingMode
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

const val START_CASH = 10000.0

data class Coin(
    val id: String, val symbol: String, val name: String, val image: String,
    val price: Double, val change24h: Double, val marketCap: Double
)

data class Holding(
    val coinId: String, val symbol: String, val name: String, val image: String,
    val qty: Double, val costUsd: Double
)

// type: BUY, SELL, SEND
data class Tx(val time: Long, val type: String, val coinId: String, val symbol: String, val qty: Double, val priceUsd: Double)

data class PriceAlert(val id: Long, val coinId: String, val symbol: String, val target: Double, val above: Boolean)

sealed interface Route {
    data class Detail(val id: String) : Route
    object Send : Route
    object Receive : Route
    object Alerts : Route
}

fun Double.safe(): Double = if (isNaN() || isInfinite()) 0.0 else this

fun qtyFmt(q: Double): String =
    BigDecimal(q.safe()).setScale(8, RoundingMode.HALF_UP).stripTrailingZeros().toPlainString()

fun pctFmt(p: Double): String =
    (if (p >= 0) "+" else "") + String.format(Locale.US, "%.2f", p.safe()) + "%"

fun dateFmt(t: Long): String =
    SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR")).format(Date(t))
