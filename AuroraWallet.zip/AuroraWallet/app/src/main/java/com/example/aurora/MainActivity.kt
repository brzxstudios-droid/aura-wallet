package com.example.aurora

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.fragment.app.FragmentActivity
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

class MainActivity : FragmentActivity() {
    private val vm: AppViewModel by viewModels()
    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        super.onCreate(savedInstanceState)
        val t0 = SystemClock.uptimeMillis()
        splash.setKeepOnScreenCondition { !vm.ready || SystemClock.uptimeMillis() - t0 < 700 }
        splash.setOnExitAnimationListener { p ->
            p.view.animate().alpha(0f).setDuration(250).withEndAction { p.remove() }.start()
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        scheduleAlerts()
        setContent {
            AuroraTheme(vm.theme, vm.accent) {
                AuroraApp(vm) { onOk -> showBiometric(onOk) }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        vm.active = true
    }

    override fun onStop() {
        super.onStop()
        vm.active = false
        vm.lockIfNeeded()
    }

    private fun scheduleAlerts() {
        val req = PeriodicWorkRequestBuilder<AlertWorker>(15, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(this)
            .enqueueUniquePeriodicWork("aurora_alerts", ExistingPeriodicWorkPolicy.KEEP, req)
    }

    private fun showBiometric(onOk: () -> Unit) {
        val auth = BiometricManager.Authenticators.BIOMETRIC_WEAK
        if (BiometricManager.from(this).canAuthenticate(auth) != BiometricManager.BIOMETRIC_SUCCESS) return
        val prompt = BiometricPrompt(
            this, ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { onOk() }
            }
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Desbloquear Aurora Wallet")
            .setNegativeButtonText("Usar PIN")
            .setAllowedAuthenticators(auth)
            .build()
        prompt.authenticate(info)
    }
}
