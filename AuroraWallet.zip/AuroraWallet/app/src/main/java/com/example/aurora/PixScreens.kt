package com.example.aurora

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun SegButton(label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier.height(44.dp).clip(RoundedCornerShape(10.dp))
            .background(if (selected) MaterialTheme.colorScheme.onBackground else MaterialTheme.colorScheme.surfaceVariant)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            label, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1,
            color = if (selected) MaterialTheme.colorScheme.background else MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
fun BankAvatar(vm: AppViewModel, b: PixBank, size: Dp, shape: Shape) {
    val file = vm.photoFile(b.id)
    if (b.photo && file.exists()) {
        AsyncImage(
            model = file, contentDescription = b.bank, contentScale = ContentScale.Crop,
            modifier = Modifier.size(size).clip(shape)
        )
    } else {
        val colors = listOf(0xFF5EEAD4, 0xFFFBBF24, 0xFFC4B5FD, 0xFFF9A8D4, 0xFF93C5FD, 0xFFFCA5A5)
        val bg = Color(colors[Math.floorMod(b.id, colors.size.toLong()).toInt()])
        val initials = b.bank.trim().split(" ").filter { it.isNotBlank() }.take(2).joinToString("") { it.take(1).uppercase() }
        Box(Modifier.size(size).clip(shape).background(bg), contentAlignment = Alignment.Center) {
            Text(initials, color = Color(0xFF111111), fontWeight = FontWeight.Bold, fontSize = (size.value * 0.33f).sp)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun BankRow(vm: AppViewModel, b: PixBank, selected: Boolean, onClick: () -> Unit, onLong: () -> Unit) {
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val edge = RoundedCornerShape(14.dp)
    Row(
        Modifier.fillMaxWidth().height(68.dp).clip(edge)
            .background(if (selected) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface)
            .border(2.dp, if (selected) MaterialTheme.colorScheme.onBackground else MaterialTheme.colorScheme.surfaceVariant, edge)
            .combinedClickable(onClick = onClick, onLongClick = onLong)
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        BankAvatar(vm, b, 42.dp, CircleShape)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(b.bank, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Text(b.contact + " · " + PixKey.describe(b.keyType, b.key), fontSize = 12.sp, color = muted, maxLines = 1)
        }
        if (selected) Icon(Icons.Filled.Check, "Selecionado")
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun BankTile(vm: AppViewModel, b: PixBank, selected: Boolean, modifier: Modifier, onClick: () -> Unit, onLong: () -> Unit) {
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val edge = RoundedCornerShape(26.dp)
    Column(
        modifier.clip(edge)
            .background(if (selected) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface)
            .border(2.dp, if (selected) MaterialTheme.colorScheme.onBackground else MaterialTheme.colorScheme.surfaceVariant, edge)
            .combinedClickable(onClick = onClick, onLongClick = onLong)
            .padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        BankAvatar(vm, b, 72.dp, RoundedCornerShape(28.dp))
        Spacer(Modifier.height(6.dp))
        Text(b.bank, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, textAlign = TextAlign.Center)
        Text(b.contact, fontSize = 11.sp, color = muted, maxLines = 1, textAlign = TextAlign.Center)
    }
}

@Composable
fun SendScreen(vm: AppViewModel) {
    var mode by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        TopBar(if (mode == 0) "Enviar Pix" else "Enviar", onBack = { vm.pop() })
        Row(Modifier.padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SegButton("Pix (R$)", mode == 0, Modifier.weight(1f)) { mode = 0 }
            SegButton("Cripto", mode == 1, Modifier.weight(1f)) { mode = 1 }
        }
        Spacer(Modifier.height(10.dp))
        Box(Modifier.weight(1f)) {
            if (mode == 0) PixSend(vm) else CryptoSend(vm)
        }
    }
}

@Composable
fun PixSend(vm: AppViewModel) {
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    var selected by remember { mutableStateOf<Long?>(null) }
    var keyType by remember { mutableIntStateOf(0) }
    var key by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var addOpen by remember { mutableStateOf(false) }
    var removing by remember { mutableStateOf<PixBank?>(null) }
    val bank = vm.banks.find { it.id == selected }
    val avail = vm.cash * vm.usdBrl

    fun pick(b: PixBank) {
        selected = b.id
        keyType = b.keyType
        key = b.key
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Pix simulado: nada sai de verdade, só o saldo fictício diminui.", color = muted, fontSize = 13.sp)
        Row {
            Text("Disponível: ", fontSize = 16.sp, color = muted)
            Text(vm.brl(avail), fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Bancos salvos", fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            TextButton(onClick = { addOpen = true }) { Text("+ Adicionar", fontWeight = FontWeight.SemiBold) }
        }
        if (vm.banks.isEmpty()) {
            Text("Nenhum banco salvo ainda. Toque em “+ Adicionar” para cadastrar um.", color = muted, fontSize = 13.sp)
        } else if (vm.pixStyle == 0) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                vm.banks.forEach { b ->
                    BankRow(vm, b, selected == b.id, onClick = { pick(b) }, onLong = { removing = b })
                }
            }
            Text("Toque e segure para remover.", color = muted, fontSize = 11.sp)
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                vm.banks.chunked(3).forEach { rowItems ->
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        rowItems.forEach { b ->
                            BankTile(vm, b, selected == b.id, Modifier.weight(1f), onClick = { pick(b) }, onLong = { removing = b })
                        }
                        repeat(3 - rowItems.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
            Text("Toque e segure para remover.", color = muted, fontSize = 11.sp)
        }

        Text("Ou digite uma chave Pix", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 4.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PixKey.LABELS.forEachIndexed { i, l ->
                SegButton(l, keyType == i, Modifier.weight(1f)) {
                    keyType = i
                    selected = null
                    key = ""
                }
            }
        }
        OutlinedTextField(
            value = key, onValueChange = { key = it.take(80); selected = null },
            singleLine = true, modifier = Modifier.fillMaxWidth(),
            placeholder = { Text(PixKey.HINTS[keyType]) },
            isError = key.isNotBlank() && !PixKey.valid(keyType, key),
            supportingText = { if (key.isNotBlank() && !PixKey.valid(keyType, key)) Text("Chave inválida para " + PixKey.LABELS[keyType]) },
            keyboardOptions = KeyboardOptions(
                keyboardType = when (keyType) { 0, 1 -> KeyboardType.Phone; 2 -> KeyboardType.Email; else -> KeyboardType.Ascii }
            )
        )
        OutlinedTextField(
            value = amount, onValueChange = { amount = it }, singleLine = true,
            modifier = Modifier.fillMaxWidth(), placeholder = { Text("Valor (R$)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
        )
        Spacer(Modifier.height(4.dp))
        Button(
            onClick = {
                val v = amount.replace(',', '.').toDoubleOrNull() ?: 0.0
                if (vm.sendPix(v, bank, keyType, key)) vm.pop()
            },
            modifier = Modifier.fillMaxWidth().height(48.dp),
            shape = RoundedCornerShape(24.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.onBackground,
                contentColor = MaterialTheme.colorScheme.background
            )
        ) { Text("Enviar Pix (demonstração)", fontWeight = FontWeight.SemiBold) }
        Spacer(Modifier.height(24.dp))
    }

    if (addOpen) AddBankDialog(vm) { addOpen = false }
    removing?.let { b ->
        AlertDialog(
            onDismissRequest = { removing = null },
            title = { Text("Remover " + b.bank + "?") },
            text = { Text("O banco e a foto salvos serão apagados do app.") },
            confirmButton = {
                TextButton(onClick = {
                    if (selected == b.id) selected = null
                    vm.removeBank(b.id)
                    removing = null
                }) { Text("Remover") }
            },
            dismissButton = { TextButton(onClick = { removing = null }) { Text("Cancelar") } }
        )
    }
}

@Composable
fun AddBankDialog(vm: AppViewModel, onDismiss: () -> Unit) {
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val scope = rememberCoroutineScope()
    val newId = remember { System.currentTimeMillis() }
    var hasPhoto by remember { mutableStateOf(false) }
    var saved by remember { mutableStateOf(false) }
    var bank by remember { mutableStateOf("") }
    var contact by remember { mutableStateOf("") }
    var type by remember { mutableIntStateOf(0) }
    var key by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val ok = withContext(Dispatchers.IO) { vm.savePhoto(newId, uri) }
                if (ok) hasPhoto = true else vm.message = "Não consegui abrir essa imagem."
            }
        }
    }
    val keyOk = PixKey.valid(type, key)
    val close: () -> Unit = {
        if (!saved && hasPhoto) vm.deletePhoto(newId)
        onDismiss()
    }
    val shape: Shape = if (vm.pixStyle == 0) CircleShape else RoundedCornerShape(28.dp)

    AlertDialog(
        onDismissRequest = close,
        title = { Text("Adicionar banco") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        Modifier.size(84.dp).clip(shape).background(MaterialTheme.colorScheme.surfaceVariant)
                            .clickable { picker.launch("image/*") },
                        contentAlignment = Alignment.Center
                    ) {
                        if (hasPhoto) {
                            AsyncImage(
                                model = vm.photoFile(newId), contentDescription = "Foto", contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Icon(Icons.Filled.AddAPhoto, "Escolher foto", tint = muted)
                        }
                    }
                    Text("Toque para escolher uma foto (opcional)", color = muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                }
                OutlinedTextField(
                    value = bank, onValueChange = { bank = it.take(30) }, singleLine = true,
                    label = { Text("Banco") }, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = contact, onValueChange = { contact = it.take(40) }, singleLine = true,
                    label = { Text("Nome do contato") }, modifier = Modifier.fillMaxWidth()
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    PixKey.LABELS.forEachIndexed { i, l ->
                        SegButton(l, type == i, Modifier.weight(1f)) { type = i; key = "" }
                    }
                }
                OutlinedTextField(
                    value = key, onValueChange = { key = it.take(80) }, singleLine = true,
                    modifier = Modifier.fillMaxWidth(), placeholder = { Text(PixKey.HINTS[type]) },
                    isError = key.isNotBlank() && !keyOk,
                    supportingText = { if (key.isNotBlank() && !keyOk) Text("Chave inválida para " + PixKey.LABELS[type]) },
                    keyboardOptions = KeyboardOptions(
                        keyboardType = when (type) { 0, 1 -> KeyboardType.Phone; 2 -> KeyboardType.Email; else -> KeyboardType.Ascii }
                    )
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = bank.isNotBlank() && contact.isNotBlank() && keyOk,
                onClick = {
                    vm.addBank(PixBank(newId, bank.trim(), contact.trim(), type, PixKey.normalize(type, key), hasPhoto))
                    saved = true
                    onDismiss()
                }
            ) { Text("Salvar") }
        },
        dismissButton = { TextButton(onClick = close) { Text("Cancelar") } }
    )
}
