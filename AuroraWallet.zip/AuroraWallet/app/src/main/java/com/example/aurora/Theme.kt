package com.example.aurora

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Accent = Color(0xFF7C5CFF)
val Positive = Color(0xFF2BB673)
val Negative = Color(0xFFE5484D)

private val DarkScheme = darkColorScheme(
    primary = Accent, background = Color(0xFF0F0F14), surface = Color(0xFF1A1A22),
    onBackground = Color.White, onSurface = Color.White,
    onSurfaceVariant = Color(0xFF8A8A99), surfaceVariant = Color(0xFF24242E)
)
private val LightScheme = lightColorScheme(
    primary = Accent, background = Color(0xFFF6F6FA), surface = Color.White,
    onBackground = Color(0xFF14141A), onSurface = Color(0xFF14141A),
    onSurfaceVariant = Color(0xFF6B6B7A), surfaceVariant = Color(0xFFE9E9F2)
)

@Composable
fun AuroraTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) DarkScheme else LightScheme, content = content)
}

fun plColor(v: Double): Color = if (v >= 0) Positive else Negative
