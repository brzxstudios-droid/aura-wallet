package com.example.aurora

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

// Cor de destaque atual (muda conforme a escolha nos Ajustes)
val Accent: Color
    @Composable get() = MaterialTheme.colorScheme.primary

val Positive = Color(0xFF2BB673)
val Negative = Color(0xFFE5484D)

// Cores mostradas nas bolinhas da tela de Ajustes
val AccentOptions = listOf(
    "Verde" to Color(0xFF2BD67B),
    "Branco" to Color(0xFFFFFFFF),
    "Cinza" to Color(0xFF9CA3AF),
    "Azul" to Color(0xFF4DA3FF)
)

fun accentColor(idx: Int, dark: Boolean): Color = when (idx) {
    1 -> if (dark) Color(0xFFFFFFFF) else Color(0xFF14141A)
    2 -> if (dark) Color(0xFF9CA3AF) else Color(0xFF6B7280)
    3 -> if (dark) Color(0xFF4DA3FF) else Color(0xFF2F7DE1)
    else -> if (dark) Color(0xFF2BD67B) else Color(0xFF1FA463)
}

// mode: 0 sistema, 1 escuro, 2 claro, 3 preto
@Composable
fun AuroraTheme(mode: Int, accentIdx: Int, content: @Composable () -> Unit) {
    val dark = when (mode) {
        1, 3 -> true
        2 -> false
        else -> isSystemInDarkTheme()
    }
    val accent = accentColor(accentIdx, dark)
    val onAccent = if (accent.luminance() > 0.5f) Color.Black else Color.White
    val base = when {
        mode == 3 -> darkColorScheme(
            primary = accent, onPrimary = onAccent,
            background = Color(0xFF000000), surface = Color(0xFF0B0B0D),
            onBackground = Color.White, onSurface = Color.White,
            onSurfaceVariant = Color(0xFF8A8A92), surfaceVariant = Color(0xFF151518)
        )
        dark -> darkColorScheme(
            primary = accent, onPrimary = onAccent,
            background = Color(0xFF0F0F14), surface = Color(0xFF1A1A22),
            onBackground = Color.White, onSurface = Color.White,
            onSurfaceVariant = Color(0xFF8A8A99), surfaceVariant = Color(0xFF24242E)
        )
        else -> lightColorScheme(
            primary = accent, onPrimary = onAccent,
            background = Color(0xFFF6F6FA), surface = Color.White,
            onBackground = Color(0xFF14141A), onSurface = Color(0xFF14141A),
            onSurfaceVariant = Color(0xFF6B6B7A), surfaceVariant = Color(0xFFE9E9F2)
        )
    }
    val scheme = base.copy(secondaryContainer = accent.copy(alpha = 0.25f), onSecondaryContainer = accent)

    val view = LocalView.current
    SideEffect {
        val w = (view.context as? Activity)?.window
        if (w != null) {
            w.statusBarColor = scheme.background.toArgb()
            w.navigationBarColor = scheme.background.toArgb()
            val c = WindowCompat.getInsetsController(w, view)
            c.isAppearanceLightStatusBars = !dark
            c.isAppearanceLightNavigationBars = !dark
        }
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

fun plColor(v: Double): Color = if (v >= 0) Positive else Negative
