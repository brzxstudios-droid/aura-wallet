package com.example.aurora

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF0F0F14)
val Card = Color(0xFF1A1A22)
val Accent = Color(0xFF7C5CFF)
val Muted = Color(0xFF8A8A99)
val Positive = Color(0xFF3DDC97)
val Negative = Color(0xFFFF6B6B)

@Composable
fun AuroraTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Card),
        content = content
    )
}
