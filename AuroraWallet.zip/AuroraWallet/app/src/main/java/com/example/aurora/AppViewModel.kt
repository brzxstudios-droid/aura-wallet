package com.example.aurora

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Locale

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val store = Store(app)
    private val ptBr = Locale("pt", "BR")

    var coins by mutableStateOf(store.loadCoins())
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var message by mutableStateOf<String?>(null)
    var live by mutableStateOf(false)
    var ready by mutableStateOf(false)
    var active = true

    var cash by mutableStateOf(store.cash)
    var startCash by mutableStateOf(store.startCash)
    var capital by mutableStateOf(store.capital)
    var holdings by mutableStateOf(store.loadHoldings())
    var txs by mutableStateOf(store.loadTxs())
    var favorites by mutableStateOf(store.favorites)
    var alerts by mutableStateOf(store.loadAlerts())

    var currency by mutableStateOf(store.currency)
    var usdBrl by mutableStateOf(store.rate)
    var theme by mutableStateOf(store.theme)
    var accent by mutableStateOf(store.accent)
    var gradient by mutableStateOf(store.gradient)
    var hideBalance by mutableStateOf(store.hideBalance)
    var notifyOn by mutableStateOf(store.notifyOn)
    var banks by mutableStateOf(store.loadBanks())
    var pixStyle by mutableStateOf(store.pixStyle)
    var pixTitle by mutableStateOf(store.pixTitle)
    var pixMessage by mutableStateOf(store.pixMessage)
    var destinations by mutableStateOf(store.destinations)
    var userName by mutableStateOf(store.userName)
    val since: Long = store.since ?: System.currentTimeMillis().also { store.since = it }
    var hasPin by mutableStateOf(store.pinHash != null)
    var biometric by mutableStateOf(store.biometric)
    var unlocked by mutableStateOf(store.pinHash == null)

    var tab by mutableStateOf(0)
    var stack by mutableStateOf(listOf<Route>())

    val address: String = store.address ?: genAddress().also { store.address = it }

    private var validPairs: Set<String> = emptySet()
    private var binanceOk = false
    private var failures = 0
    private val histCache = HashMap<String, Pair<Long, List<Pair<Long, Double>>>>()
    private val wealthCache = HashMap<String, Pair<Long, List<Double>>>()

    init {
        viewModelScope.launch {
            refreshMeta()
            refreshBinanceAll()
            ready = true
        }
        viewModelScope.launch {
            delay(1800)
            ready = true
        }
        // Preços ao vivo: a cada 3 s (só com o app aberto)
        viewModelScope.launch {
            var tick = 0
            while (true) {
                delay(3000)
                if (!active) continue
                tick++
                if (binanceOk) {
                    refreshLive()
                    if (tick % 10 == 0) refresh24h()
                } else if (tick % 10 == 0) {
                    refreshBinanceAll()
                    if (!binanceOk) refreshMeta()
                }
            }
        }
        // Nomes, logos e valor de mercado: a cada 5 min
        viewModelScope.launch {
            while (true) {
                delay(300_000)
                if (active) refreshMeta()
            }
        }
    }

    private fun genAddress(): String {
        val r = SecureRandom()
        val hex = "0123456789abcdef"
        return "0x" + (1..40).map { hex[r.nextInt(16)] }.joinToString("")
    }

    private fun sha(s: String): String =
        MessageDigest.getInstance("SHA-256").digest(("aurora:$s").toByteArray()).joinToString("") { "%02x".format(it) }

    // ---------- Dados de mercado ----------
    fun refresh() {
        viewModelScope.launch {
            loading = true
            refreshMeta()
            if (binanceOk) {
                refreshLive()
                refresh24h()
            } else {
                refreshBinanceAll()
            }
            alerts = store.loadAlerts()
            loading = false
        }
    }

    private suspend fun refreshMeta() {
        try {
            val list = Api.markets()
            if (list.isNotEmpty()) {
                val old = coins.associateBy { it.id }
                coins = list.map { c ->
                    val o = old[c.id]
                    // Mantém o preço ao vivo da Binance quando o par existe
                    if (o != null && o.price > 0 && (c.symbol + "USDT") in validPairs) c.copy(price = o.price, change24h = o.change24h) else c
                }
                store.saveCoins(coins)
                error = null
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            if (coins.isEmpty()) coins = Api.fallbackCoins()
            if (!binanceOk && !live) error = "Sem conexão com a API de preços. Mostrando os últimos valores salvos."
        }
    }

    private suspend fun refreshBinanceAll() {
        try {
            val all = Api.binanceAll()
            validPairs = all.keys.toSet()
            binanceOk = true
            failures = 0
            applyPrices(all)
            all["USDTBRL"]?.let { usdBrl = it; store.rate = it }
            live = true
            error = null
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            binanceOk = false
            live = false
            try {
                usdBrl = Api.usdBrl()
                store.rate = usdBrl
            } catch (e2: CancellationException) {
                throw e2
            } catch (e2: Exception) {
            }
        }
    }

    private fun trackedSymbols(): List<String> =
        coins.map { it.symbol + "USDT" }.filter { it in validPairs }.distinct().take(99)

    private suspend fun refreshLive() {
        try {
            val p = Api.binancePrices(trackedSymbols() + "USDTBRL")
            applyPrices(p)
            p["USDTBRL"]?.let { usdBrl = it }
            live = true
            failures = 0
            error = null
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            live = false
            failures++
            if (failures >= 3) binanceOk = false
        }
    }

    private suspend fun refresh24h() {
        try {
            val m = Api.binance24h(trackedSymbols())
            if (m.isNotEmpty()) {
                coins = coins.map { c ->
                    val t = m[c.symbol + "USDT"]
                    if (t != null) c.copy(price = if (t.first > 0) t.first else c.price, change24h = t.second) else c
                }
                store.saveCoins(coins)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
        }
    }

    private fun applyPrices(p: Map<String, Double>) {
        var changed = false
        val n = coins.map { c ->
            val np = p[c.symbol + "USDT"]
            if (np != null && np > 0 && np != c.price) { changed = true; c.copy(price = np) } else c
        }
        if (changed) coins = n
    }

    /** Histórico de preços (horário em ms, preço) de uma moeda no período escolhido. */
    suspend fun history(id: String, symbol: String, idx: Int): List<Pair<Long, Double>> {
        val key = "$id:$idx"
        val now = System.currentTimeMillis()
        histCache[key]?.let { if (now - it.first < 60_000) return it.second }
        val cfg = Ranges[idx]
        val pair = symbol + "USDT"
        val data = if (pair in validPairs) {
            try {
                Api.klines(pair, cfg.interval, cfg.limit)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Api.geckoChart(id, cfg.days)
            }
        } else {
            Api.geckoChart(id, cfg.days)
        }
        histCache[key] = now to data
        return data
    }

    private fun priceAt(s: List<Pair<Long, Double>>, t: Long, fallback: Double): Double {
        if (s.isEmpty()) return fallback
        if (t <= s[0].first) return s[0].second
        var lo = 0
        var hi = s.size - 1
        while (lo < hi) {
            val mid = (lo + hi + 1) ushr 1
            if (s[mid].first <= t) lo = mid else hi = mid - 1
        }
        return s[lo].second
    }

    /**
     * Evolução do patrimônio no período: reconstruída com as suas transações reais
     * (compras, vendas e envios) e os preços históricos reais de cada moeda.
     */
    suspend fun wealth(idx: Int): List<Double> {
        val key = idx.toString() + ":" + txs.size
        val now = System.currentTimeMillis()
        wealthCache[key]?.let { if (now - it.first < 30_000) return it.second }
        val cfg = Ranges[idx]
        val sorted = txs.sortedBy { it.time }
        val n = cfg.limit
        val step = cfg.spanMs / (n - 1)
        val out = ArrayList<Double>(n)
        if (sorted.isEmpty()) {
            repeat(n) { out.add(startCash) }
        } else {
            val series = HashMap<String, List<Pair<Long, Double>>>()
            for (id in sorted.filter { it.type == "BUY" || it.type == "SELL" || it.type == "SEND" }.map { it.coinId }.distinct()) {
                val sym = sorted.first { it.coinId == id }.symbol
                series[id] = try {
                    history(id, sym, idx)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    emptyList()
                }
            }
            var c = startCash
            val qty = HashMap<String, Double>()
            var ti = 0
            for (k in 0 until n) {
                val t = now - cfg.spanMs + k * step
                while (ti < sorted.size && sorted[ti].time <= t) {
                    val x = sorted[ti]
                    val cur = qty[x.coinId] ?: 0.0
                    when (x.type) {
                        "BUY" -> { c -= x.qty * x.priceUsd; qty[x.coinId] = cur + x.qty }
                        "SELL" -> { c += x.qty * x.priceUsd; qty[x.coinId] = cur - x.qty }
                        "DEPOSIT" -> { c += x.qty }
                        "PIX" -> { c -= x.qty * x.priceUsd }
                        else -> { qty[x.coinId] = cur - x.qty }
                    }
                    ti++
                }
                var v = c
                for ((id, q) in qty) {
                    if (q > 1e-12) v += q * priceAt(series[id] ?: emptyList(), t, price(id))
                }
                out.add(v)
            }
        }
        out[out.size - 1] = totalValue()
        wealthCache[key] = now to out
        return out
    }

    fun price(id: String): Double =
        coins.find { it.id == id }?.price
            ?: holdings.find { it.coinId == id }?.let { if (it.qty > 0) it.costUsd / it.qty else 0.0 }
            ?: 0.0

    fun holdingValue(h: Holding): Double = h.qty * price(h.coinId)
    fun holdingsValue(): Double = holdings.sumOf { holdingValue(it) }
    fun totalValue(): Double = cash + holdingsValue()

    fun money(usd: Double, signed: Boolean = false): String {
        val btcUsd = price("bitcoin")
        if (currency == "BTC" && btcUsd > 0) {
            val b = (usd / btcUsd).safe()
            val sign = if (b < 0) "-" else if (signed) "+" else ""
            return sign + "₿ " + String.format(Locale.US, "%.8f", Math.abs(b))
        }
        val brl = currency == "BRL"
        val v = (if (brl) usd * usdBrl else usd).safe()
        val loc = if (brl) ptBr else Locale.US
        val a = Math.abs(v)
        val body = if (a != 0.0 && a < 1.0) String.format(loc, "%,.6f", a) else String.format(loc, "%,.2f", a)
        val sign = if (v < 0) "-" else if (signed) "+" else ""
        return sign + (if (brl) "R$ " else "$") + body
    }

    fun moneyH(usd: Double, signed: Boolean = false): String =
        if (hideBalance) "••••" else money(usd, signed)

    fun toUsd(display: Double): Double {
        val btcUsd = price("bitcoin")
        return when {
            currency == "BTC" && btcUsd > 0 -> display * btcUsd
            currency == "BRL" && usdBrl > 0 -> display / usdBrl
            else -> display
        }
    }

    fun fromUsd(usd: Double): Double {
        val btcUsd = price("bitcoin")
        return when {
            currency == "BTC" && btcUsd > 0 -> usd / btcUsd
            currency == "BRL" -> usd * usdBrl
            else -> usd
        }
    }

    // ---------- Negociação (fictícia) ----------
    private fun persist() {
        store.cash = cash
        store.saveHoldings(holdings)
        store.saveTxs(txs)
    }

    fun buy(coin: Coin, usd: Double): Boolean {
        if (usd <= 0.0 || coin.price <= 0.0) { message = "Informe um valor válido."; return false }
        if (usd > cash + 1e-9) { message = "Saldo demonstrativo insuficiente."; return false }
        val qty = usd / coin.price
        val old = holdings.find { it.coinId == coin.id }
        val nh = if (old == null) Holding(coin.id, coin.symbol, coin.name, coin.image, qty, usd)
        else old.copy(qty = old.qty + qty, costUsd = old.costUsd + usd)
        holdings = holdings.filter { it.coinId != coin.id } + nh
        cash = (cash - usd).coerceAtLeast(0.0)
        txs = listOf(Tx(System.currentTimeMillis(), "BUY", coin.id, coin.symbol, qty, coin.price)) + txs
        persist()
        message = "Compra realizada: " + qtyFmt(qty) + " " + coin.symbol
        return true
    }

    fun sell(coin: Coin, qty: Double): Boolean {
        val old = holdings.find { it.coinId == coin.id }
        if (old == null || qty <= 0.0) { message = "Informe uma quantidade válida."; return false }
        if (qty > old.qty + 1e-12) { message = "Você não tem essa quantidade."; return false }
        val q = qty.coerceAtMost(old.qty)
        val costPart = old.costUsd * (q / old.qty)
        val left = old.qty - q
        holdings = holdings.filter { it.coinId != coin.id } +
            (if (left > 1e-10) listOf(old.copy(qty = left, costUsd = old.costUsd - costPart)) else emptyList())
        cash += q * coin.price
        txs = listOf(Tx(System.currentTimeMillis(), "SELL", coin.id, coin.symbol, q, coin.price)) + txs
        persist()
        message = "Venda realizada: " + qtyFmt(q) + " " + coin.symbol
        return true
    }

    fun send(h: Holding, qty: Double, address: String, destName: String = ""): Boolean {
        if (!Regex("^0x[0-9a-fA-F]{40}$").matches(address.trim())) { message = "Endereço inválido (use 0x + 40 caracteres)."; return false }
        if (qty <= 0.0 || qty > h.qty + 1e-12) { message = "Quantidade inválida."; return false }
        val q = qty.coerceAtMost(h.qty)
        val left = h.qty - q
        val costPart = h.costUsd * (q / h.qty)
        holdings = holdings.filter { it.coinId != h.coinId } +
            (if (left > 1e-10) listOf(h.copy(qty = left, costUsd = h.costUsd - costPart)) else emptyList())
        txs = listOf(Tx(System.currentTimeMillis(), "SEND", h.coinId, h.symbol, q, price(h.coinId))) + txs
        persist()
        val name = destName.trim()
        val addr = address.trim()
        val dest = if (name.isNotBlank()) name else addr.take(6) + "…" + addr.takeLast(4)
        if (name.isNotBlank()) {
            destinations = (listOf(name) + destinations.filter { it != name }).take(6)
            store.destinations = destinations
        }
        val done = "Envio simulado: " + qtyFmt(q) + " " + h.symbol
        message = done
        if (notifyOn) {
            val app = getApplication<Application>()
            val text = "Você enviou " + qtyFmt(q) + " " + h.symbol + " (≈ " + money(q * price(h.coinId)) + ") para " + dest + "."
            viewModelScope.launch {
                val code = withContext(Dispatchers.IO) { Notifier.send(app, "Envio concluído", text) }
                val n = noticeFor(code)
                if (n.isNotEmpty()) message = done + "." + n
            }
        }
        return true
    }

    fun resetDemo() {
        cash = startCash
        capital = startCash
        holdings = emptyList()
        txs = emptyList()
        wealthCache.clear()
        store.capital = capital
        persist()
        message = "Demonstração reiniciada."
    }

    /** Define um novo saldo inicial e recomeça a demonstração (apaga ativos e histórico). */
    fun setInitialBalance(usd: Double): Boolean {
        if (usd <= 0.0 || usd > 1e12 || usd.isNaN()) { message = "Informe um valor válido."; return false }
        startCash = usd
        capital = usd
        cash = usd
        holdings = emptyList()
        txs = emptyList()
        wealthCache.clear()
        store.startCash = usd
        store.capital = usd
        persist()
        message = "Saldo inicial definido: " + money(usd)
        return true
    }

    /** Adiciona saldo fictício como depósito (não conta como lucro). */
    fun deposit(usd: Double): Boolean {
        if (usd <= 0.0 || usd > 1e12 || usd.isNaN()) { message = "Informe um valor válido."; return false }
        cash += usd
        capital += usd
        txs = listOf(Tx(System.currentTimeMillis(), "DEPOSIT", "", "USD", usd, 1.0)) + txs
        store.capital = capital
        persist()
        message = "Saldo adicionado: " + money(usd)
        return true
    }

    fun currencySymbol(): String = when (currency) { "BRL" -> "R$"; "BTC" -> "₿"; else -> "US$" }

    // ---------- Favoritos e alertas ----------
    fun toggleFavorite(id: String) {
        favorites = if (id in favorites) favorites - id else favorites + id
        store.favorites = favorites
    }

    fun addAlert(coin: Coin, target: Double, above: Boolean) {
        alerts = store.loadAlerts() + PriceAlert(System.currentTimeMillis(), coin.id, coin.symbol, target, above)
        store.saveAlerts(alerts)
        message = "Alerta criado para " + coin.symbol
    }

    fun removeAlert(id: Long) {
        alerts = store.loadAlerts().filter { it.id != id }
        store.saveAlerts(alerts)
    }

    // ---------- Ajustes, perfil e segurança ----------
    fun updateCurrency(c: String) { currency = c; store.currency = c }
    fun updateTheme(t: Int) { theme = t; store.theme = t }
    fun updateAccent(a: Int) { accent = a; store.accent = a }
    fun updateGradient(g: Boolean) { gradient = g; store.gradient = g }
    fun toggleHide() { hideBalance = !hideBalance; store.hideBalance = hideBalance }
    fun updateNotify(on: Boolean) { notifyOn = on; store.notifyOn = on }
    fun notifierInstalled(): Boolean = Notifier.isInstalled(getApplication<Application>())
    private fun noticeFor(code: Int): String = when (code) {
        1 -> ""
        2 -> " O Aurora Avisos está sem permissão para notificar: abra-o e toque em Permitir notificações."
        0 -> " Aviso enviado sem confirmação: atualize o Aurora Avisos para a versão mais nova."
        -1 -> " Instale e abra o Aurora Avisos para receber a notificação."
        else -> " Não consegui enviar o aviso ao Aurora Avisos."
    }

    fun sendTestNotification() {
        val app = getApplication<Application>()
        viewModelScope.launch {
            val code = withContext(Dispatchers.IO) {
                Notifier.send(app, "Aviso de teste", "O Aurora Wallet está conectado ao Aurora Avisos.")
            }
            message = if (code == 1) "Aviso de teste entregue ao Aurora Avisos." else "Falha no aviso de teste." + noticeFor(code)
        }
    }
    // ---------- Pix (simulado) ----------
    fun brl(v: Double): String = "R$ " + String.format(ptBr, "%,.2f", v)

    /** Retorno em %, ignorando o caso de capital zerado. */
    fun pnlPct(pl: Double): Double = if (capital > 1e-9) pl / capital * 100 else 0.0

    fun updatePixStyle(s: Int) { pixStyle = s; store.pixStyle = s }
    fun updatePixTitle(t: String) { pixTitle = t.take(60); store.pixTitle = pixTitle }
    fun updatePixMessage(t: String) { pixMessage = t.take(160); store.pixMessage = pixMessage }
    fun resetPixNotif() {
        updatePixTitle(PIX_TITLE_DEFAULT)
        updatePixMessage(PIX_MESSAGE_DEFAULT)
    }

    fun photoFile(id: Long): File = File(getApplication<Application>().filesDir, "pix_$id.jpg")
    fun deletePhoto(id: Long) { photoFile(id).delete() }

    /** Salva a foto escolhida como imagem quadrada 256x256. Chame fora da thread principal. */
    fun savePhoto(id: Long, uri: Uri): Boolean = try {
        val cr = getApplication<Application>().contentResolver
        val bounds = BitmapFactory.Options()
        bounds.inJustDecodeBounds = true
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var s = 1
        while (bounds.outWidth / s > 1024 || bounds.outHeight / s > 1024) s *= 2
        val o = BitmapFactory.Options()
        o.inSampleSize = s
        val src = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        if (src == null) {
            false
        } else {
            val side = minOf(src.width, src.height)
            val sq = Bitmap.createBitmap(src, (src.width - side) / 2, (src.height - side) / 2, side, side)
            val out = Bitmap.createScaledBitmap(sq, 256, 256, true)
            FileOutputStream(photoFile(id)).use { out.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            true
        }
    } catch (e: Exception) {
        false
    }

    fun addBank(b: PixBank) {
        banks = banks + b
        store.saveBanks(banks)
    }

    fun removeBank(id: Long) {
        banks = banks.filter { it.id != id }
        store.saveBanks(banks)
        deletePhoto(id)
    }

    private fun pixText(template: String, valor: String, nome: String, banco: String, chave: String): String =
        template.replace("{valor}", valor).replace("{nome}", nome).replace("{banco}", banco).replace("{chave}", chave)

    private fun notifyAsync(title: String, text: String, done: String) {
        if (!notifyOn) return
        val app = getApplication<Application>()
        viewModelScope.launch {
            val code = withContext(Dispatchers.IO) { Notifier.send(app, title, text) }
            val n = noticeFor(code)
            if (n.isNotEmpty()) message = done + "." + n
        }
    }

    /** Pix simulado: o valor em reais sai do saldo disponível. */
    fun sendPix(amountBrl: Double, bank: PixBank?, keyType: Int, key: String): Boolean {
        if (usdBrl <= 0.0) { message = "Cotação do real indisponível. Tente de novo."; return false }
        if (amountBrl < 0.01 || amountBrl.isNaN() || amountBrl > 1e12) { message = "Informe um valor válido."; return false }
        val usd = amountBrl / usdBrl
        if (usd > cash + 1e-9) { message = "Saldo disponível insuficiente."; return false }
        val t = bank?.keyType ?: keyType
        val k = bank?.key ?: key
        if (!PixKey.valid(t, k)) { message = "Chave Pix inválida (" + PixKey.LABELS[t] + ")."; return false }
        val nome = bank?.contact ?: "chave informada"
        val banco = bank?.bank ?: "Pix"
        cash = (cash - usd).coerceAtLeast(0.0)
        capital -= usd // saída de dinheiro: não conta como prejuízo
        store.capital = capital
        txs = listOf(Tx(System.currentTimeMillis(), "PIX", bank?.id?.toString() ?: "", "BRL", amountBrl, usd / amountBrl, nome + " · " + banco)) + txs
        persist()
        val done = "Pix simulado enviado: " + brl(amountBrl) + " para " + nome
        message = done
        val chave = PixKey.describe(t, k)
        notifyAsync(
            pixText(pixTitle, brl(amountBrl), nome, banco, chave),
            pixText(pixMessage, brl(amountBrl), nome, banco, chave), done
        )
        return true
    }

    fun sendPixTestNotification() {
        val app = getApplication<Application>()
        val title = pixText(pixTitle, "R$ 10,00", "Contato de teste", "Banco de teste", "CPF ***.000.000-**")
        val text = pixText(pixMessage, "R$ 10,00", "Contato de teste", "Banco de teste", "CPF ***.000.000-**")
        viewModelScope.launch {
            val code = withContext(Dispatchers.IO) { Notifier.send(app, title, text) }
            message = if (code == 1) "Aviso do Pix de teste entregue." else "Falha no aviso do Pix." + noticeFor(code)
        }
    }

    fun updateName(n: String) { userName = n.trim(); store.userName = userName }

    fun setPin(pin: String?) {
        if (pin == null) {
            store.pinHash = null
            hasPin = false
            biometric = false
            store.biometric = false
        } else {
            store.pinHash = sha(pin)
            hasPin = true
        }
        unlocked = true
    }

    fun updateBiometric(on: Boolean) { biometric = on; store.biometric = on }

    fun tryUnlock(input: String): Boolean {
        val ok = store.pinHash != null && store.pinHash == sha(input)
        if (ok) unlocked = true
        return ok
    }

    fun lockIfNeeded() { if (hasPin) unlocked = false }

    // ---------- Navegação ----------
    fun push(r: Route) { stack = stack + r }
    fun pop() { if (stack.isNotEmpty()) stack = stack.dropLast(1) }
    fun openCoin(id: String) = push(Route.Detail(id))
}
