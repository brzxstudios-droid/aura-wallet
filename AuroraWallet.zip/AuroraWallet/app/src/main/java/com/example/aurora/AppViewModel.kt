package com.example.aurora

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Locale

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val store = Store(app)

    var coins by mutableStateOf(store.loadCoins())
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var message by mutableStateOf<String?>(null)

    var cash by mutableStateOf(store.cash)
    var holdings by mutableStateOf(store.loadHoldings())
    var txs by mutableStateOf(store.loadTxs())
    var favorites by mutableStateOf(store.favorites)
    var alerts by mutableStateOf(store.loadAlerts())

    var currency by mutableStateOf(store.currency)
    var usdBrl by mutableStateOf(store.rate)
    var theme by mutableStateOf(store.theme)
    var hasPin by mutableStateOf(store.pinHash != null)
    var biometric by mutableStateOf(store.biometric)
    var unlocked by mutableStateOf(store.pinHash == null)

    var tab by mutableStateOf(0)
    var stack by mutableStateOf(listOf<Route>())

    val address: String = store.address ?: genAddress().also { store.address = it }

    init {
        viewModelScope.launch {
            while (true) {
                doRefresh()
                delay(60_000)
            }
        }
    }

    private fun genAddress(): String {
        val r = SecureRandom()
        val hex = "0123456789abcdef"
        return "0x" + (1..40).map { hex[r.nextInt(16)] }.joinToString("")
    }

    private fun sha(s: String): String =
        MessageDigest.getInstance("SHA-256").digest(("aurora:$s").toByteArray()).joinToString("") { "%02x".format(it) }

    // ---------- Preços ----------
    fun refresh() { viewModelScope.launch { doRefresh() } }

    private suspend fun doRefresh() {
        loading = true
        try {
            val list = Api.markets()
            if (list.isNotEmpty()) {
                coins = list
                store.saveCoins(list)
            }
            try {
                usdBrl = Api.usdBrl()
                store.rate = usdBrl
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
            }
            error = null
            alerts = store.loadAlerts()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            error = "Sem conexão com a API de preços. Mostrando os últimos valores salvos."
        }
        loading = false
    }

    fun price(id: String): Double =
        coins.find { it.id == id }?.price
            ?: holdings.find { it.coinId == id }?.let { if (it.qty > 0) it.costUsd / it.qty else 0.0 }
            ?: 0.0

    fun holdingValue(h: Holding): Double = h.qty * price(h.coinId)
    fun holdingsValue(): Double = holdings.sumOf { holdingValue(it) }
    fun totalValue(): Double = cash + holdingsValue()

    fun money(usd: Double, signed: Boolean = false): String {
        val brl = currency == "BRL"
        val v = (if (brl) usd * usdBrl else usd).safe()
        val loc = if (brl) Locale("pt", "BR") else Locale.US
        val a = Math.abs(v)
        val body = if (a != 0.0 && a < 1.0) String.format(loc, "%,.6f", a) else String.format(loc, "%,.2f", a)
        val sign = if (v < 0) "-" else if (signed) "+" else ""
        return sign + (if (brl) "R$ " else "$") + body
    }

    // Converte um valor digitado na moeda de exibição para dólar
    fun toUsd(display: Double): Double = if (currency == "BRL" && usdBrl > 0) display / usdBrl else display
    fun fromUsd(usd: Double): Double = if (currency == "BRL") usd * usdBrl else usd

    // ---------- Negociação (fictícia) ----------
    private fun persist() {
        store.cash = cash
        store.saveHoldings(holdings)
        store.saveTxs(txs)
    }

    fun buy(coin: Coin, usd: Double): Boolean {
        if (usd <= 0.0 || coin.price <= 0.0) { message = "Informe um valor válido."; return false }
        if (usd > cash + 1e-9) { message = "Saldo demonstrativo insuficiente."; return false }
        val qty = usd / coin.price
        val old = holdings.find { it.coinId == coin.id }
        val nh = if (old == null) Holding(coin.id, coin.symbol, coin.name, coin.image, qty, usd)
        else old.copy(qty = old.qty + qty, costUsd = old.costUsd + usd)
        holdings = holdings.filter { it.coinId != coin.id } + nh
        cash = (cash - usd).coerceAtLeast(0.0)
        txs = listOf(Tx(System.currentTimeMillis(), "BUY", coin.id, coin.symbol, qty, coin.price)) + txs
        persist()
        message = "Compra realizada: " + qtyFmt(qty) + " " + coin.symbol
        return true
    }

    fun sell(coin: Coin, qty: Double): Boolean {
        val old = holdings.find { it.coinId == coin.id }
        if (old == null || qty <= 0.0) { message = "Informe uma quantidade válida."; return false }
        if (qty > old.qty + 1e-12) { message = "Você não tem essa quantidade."; return false }
        val q = qty.coerceAtMost(old.qty)
        val costPart = old.costUsd * (q / old.qty)
        val left = old.qty - q
        holdings = holdings.filter { it.coinId != coin.id } +
            (if (left > 1e-10) listOf(old.copy(qty = left, costUsd = old.costUsd - costPart)) else emptyList())
        cash += q * coin.price
        txs = listOf(Tx(System.currentTimeMillis(), "SELL", coin.id, coin.symbol, q, coin.price)) + txs
        persist()
        message = "Venda realizada: " + qtyFmt(q) + " " + coin.symbol
        return true
    }

    fun send(h: Holding, qty: Double, address: String): Boolean {
        if (!Regex("^0x[0-9a-fA-F]{40}$").matches(address.trim())) { message = "Endereço inválido (use 0x + 40 caracteres)."; return false }
        if (qty <= 0.0 || qty > h.qty + 1e-12) { message = "Quantidade inválida."; return false }
        val q = qty.coerceAtMost(h.qty)
        val left = h.qty - q
        val costPart = h.costUsd * (q / h.qty)
        holdings = holdings.filter { it.coinId != h.coinId } +
            (if (left > 1e-10) listOf(h.copy(qty = left, costUsd = h.costUsd - costPart)) else emptyList())
        txs = listOf(Tx(System.currentTimeMillis(), "SEND", h.coinId, h.symbol, q, price(h.coinId))) + txs
        persist()
        message = "Envio simulado: " + qtyFmt(q) + " " + h.symbol
        return true
    }

    fun resetDemo() {
        cash = START_CASH
        holdings = emptyList()
        txs = emptyList()
        persist()
        message = "Demonstração reiniciada."
    }

    // ---------- Favoritos e alertas ----------
    fun toggleFavorite(id: String) {
        favorites = if (id in favorites) favorites - id else favorites + id
        store.favorites = favorites
    }

    fun addAlert(coin: Coin, target: Double, above: Boolean) {
        alerts = store.loadAlerts() + PriceAlert(System.currentTimeMillis(), coin.id, coin.symbol, target, above)
        store.saveAlerts(alerts)
        message = "Alerta criado para " + coin.symbol
    }

    fun removeAlert(id: Long) {
        alerts = store.loadAlerts().filter { it.id != id }
        store.saveAlerts(alerts)
    }

    // ---------- Ajustes e segurança ----------
    fun setCurrency(c: String) { currency = c; store.currency = c }
    fun setTheme(t: Int) { theme = t; store.theme = t }

    fun setPin(pin: String?) {
        if (pin == null) {
            store.pinHash = null
            hasPin = false
            biometric = false
            store.biometric = false
        } else {
            store.pinHash = sha(pin)
            hasPin = true
        }
        unlocked = true
    }

    fun setBiometric(on: Boolean) { biometric = on; store.biometric = on }

    fun tryUnlock(input: String): Boolean {
        val ok = store.pinHash != null && store.pinHash == sha(input)
        if (ok) unlocked = true
        return ok
    }

    fun lockIfNeeded() { if (hasPin) unlocked = false }

    // ---------- Navegação ----------
    fun push(r: Route) { stack = stack + r }
    fun pop() { if (stack.isNotEmpty()) stack = stack.dropLast(1) }
    fun openCoin(id: String) = push(Route.Detail(id))
}
