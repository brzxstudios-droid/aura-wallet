package com.example.aurora

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import java.util.Locale

class AlertWorker(ctx: Context, p: WorkerParameters) : CoroutineWorker(ctx, p) {
    override suspend fun doWork(): Result {
        val store = Store(applicationContext)
        val alerts = store.loadAlerts()
        if (alerts.isEmpty()) return Result.success()
        return try {
            val coins = Api.markets()
            val remaining = mutableListOf<PriceAlert>()
            alerts.forEach { a ->
                val c = coins.find { it.id == a.coinId }
                val hit = c != null && (if (a.above) c.price >= a.target else c.price <= a.target)
                if (hit && c != null) showNotification(a, c.price) else remaining.add(a)
            }
            store.saveAlerts(remaining)
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    @SuppressLint("MissingPermission")
    private fun showNotification(a: PriceAlert, price: Double) {
        val ctx = applicationContext
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel("alerts", "Alertas de preço", NotificationManager.IMPORTANCE_DEFAULT)
            ctx.getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
        val dir = if (a.above) "subiu acima de" else "caiu abaixo de"
        val n = NotificationCompat.Builder(ctx, "alerts")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(a.symbol + " atingiu seu alvo")
            .setContentText(a.symbol + " " + dir + " US$ " + String.format(Locale.US, "%,.2f", a.target) +
                " (agora US$ " + String.format(Locale.US, "%,.2f", price) + ")")
            .setAutoCancel(true)
            .build()
        NotificationManagerCompat.from(ctx).notify(a.id.toInt(), n)
    }
}
