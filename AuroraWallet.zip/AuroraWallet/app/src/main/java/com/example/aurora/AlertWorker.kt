package com.example.aurora

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import java.util.Locale

class AlertWorker(ctx: Context, p: WorkerParameters) : CoroutineWorker(ctx, p) {
    override suspend fun doWork(): Result {
        val store = Store(applicationContext)
        val alerts = store.loadAlerts()
        if (alerts.isEmpty()) return Result.success()
        return try {
            val prices: Map<String, Double> = try { Api.binanceAll() } catch (e: Exception) { emptyMap() }
            var gecko: List<Coin>? = null
            val remaining = mutableListOf<PriceAlert>()
            alerts.forEach { a ->
                var p: Double? = prices[a.symbol + "USDT"]
                if (p == null) {
                    if (gecko == null) gecko = try { Api.markets() } catch (e: Exception) { emptyList() }
                    p = gecko?.find { it.id == a.coinId }?.price
                }
                val hit = p != null && p > 0 && (if (a.above) p >= a.target else p <= a.target)
                if (hit && p != null) showNotification(a, p) else remaining.add(a)
            }
            store.saveAlerts(remaining)
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    @SuppressLint("MissingPermission")
    private fun showNotification(a: PriceAlert, price: Double) {
        val ctx = applicationContext
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel("alerts", "Alertas de preço", NotificationManager.IMPORTANCE_DEFAULT)
            ctx.getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
        val dir = if (a.above) "subiu acima de" else "caiu abaixo de"
        val n = NotificationCompat.Builder(ctx, "alerts")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(a.symbol + " atingiu seu alvo")
            .setContentText(a.symbol + " " + dir + " US$ " + String.format(Locale.US, "%,.2f", a.target) +
                " (agora US$ " + String.format(Locale.US, "%,.2f", price) + ")")
            .setAutoCancel(true)
            .build()
        NotificationManagerCompat.from(ctx).notify(a.id.toInt(), n)
    }
}
