package com.example.aurora

import android.util.Patterns

// Tipos de chave Pix: 0 CPF, 1 Celular, 2 E-mail, 3 Aleatória
object PixKey {
    val LABELS = listOf("CPF", "Celular", "E-mail", "Aleatória")
    val HINTS = listOf(
        "CPF: 000.000.000-00", "Celular: (11) 90000-0000",
        "E-mail: nome@exemplo.com", "Aleatória: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
    )

    private fun digits(s: String): String = s.filter { it.isDigit() }

    private fun phoneDigits(s: String): String {
        val d = digits(s)
        return if (d.startsWith("55") && d.length >= 12) d.drop(2) else d
    }

    private fun validCpf(s: String): Boolean {
        val d = digits(s)
        if (d.length != 11 || d.all { it == d[0] }) return false
        fun dv(n: Int): Int {
            var sum = 0
            for (i in 0 until n) sum += (d[i] - '0') * (n + 1 - i)
            val r = (sum * 10) % 11
            return if (r == 10) 0 else r
        }
        return dv(9) == d[9] - '0' && dv(10) == d[10] - '0'
    }

    private fun validPhone(s: String): Boolean {
        val d = phoneDigits(s)
        return d.length == 11 && d[0] != '0' && d[2] == '9'
    }

    private fun validEmail(s: String): Boolean = Patterns.EMAIL_ADDRESS.matcher(s.trim()).matches()

    private fun validRandom(s: String): Boolean =
        Regex("^[0-9a-fA-F]{8}-?[0-9a-fA-F]{4}-?[0-9a-fA-F]{4}-?[0-9a-fA-F]{4}-?[0-9a-fA-F]{12}$").matches(s.trim())

    fun valid(type: Int, key: String): Boolean = when (type) {
        0 -> validCpf(key)
        1 -> validPhone(key)
        2 -> validEmail(key)
        else -> validRandom(key)
    }

    /** Guarda a chave num formato padrão. */
    fun normalize(type: Int, key: String): String = when (type) {
        0 -> digits(key)
        1 -> phoneDigits(key)
        2 -> key.trim().lowercase()
        else -> key.trim().lowercase()
    }

    /** Texto para mostrar abaixo do nome, com a chave parcialmente oculta quando for CPF. */
    fun describe(type: Int, key: String): String = when (type) {
        0 -> {
            val d = digits(key)
            if (d.length == 11) "CPF ***." + d.substring(3, 6) + "." + d.substring(6, 9) + "-**" else "CPF"
        }
        1 -> {
            val d = phoneDigits(key)
            if (d.length == 11) "Celular (" + d.substring(0, 2) + ") " + d.substring(2, 7) + "-" + d.substring(7) else "Celular"
        }
        2 -> key
        else -> "Aleatória " + key.take(8) + "…"
    }
}
