package com.example.aurora

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CancellationException
import java.util.Locale

@Composable
fun DetailScreen(vm: AppViewModel, id: String) {
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val coin = vm.coins.find { it.id == id }
    val holding = vm.holdings.find { it.coinId == id }
    var rangeIdx by remember { mutableIntStateOf(1) }
    var chart by remember { mutableStateOf<List<Double>?>(null) }
    var failed by remember { mutableStateOf(false) }
    var sel by remember { mutableStateOf<Int?>(null) }
    var sheet by remember { mutableStateOf<Boolean?>(null) } // true = comprar, false = vender
    var alertOpen by remember { mutableStateOf(false) }

    LaunchedEffect(id, rangeIdx, coin != null) {
        if (coin != null) {
            chart = null
            failed = false
            sel = null
            try {
                chart = vm.history(id, coin.symbol, rangeIdx).map { it.second }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                failed = true
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        TopBar(coin?.name ?: holding?.name ?: id, onBack = { vm.pop() }) {
            IconButton(onClick = { vm.toggleFavorite(id) }) {
                Icon(if (id in vm.favorites) Icons.Filled.Star else Icons.Filled.StarBorder, "Favoritar", tint = Accent)
            }
            IconButton(onClick = { alertOpen = true }) { Icon(Icons.Filled.NotificationsActive, "Criar alerta") }
        }
        if (coin == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Aguardando dados da moeda...", color = muted)
            }
        } else {
            LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item {
                    val ch = chart?.let { c -> if (c.size > 1) c.dropLast(1) + coin.price else c }
                    val shown = sel?.let { ch?.getOrNull(it) } ?: coin.price
                    Text(vm.money(shown), fontSize = 34.sp, fontWeight = FontWeight.Bold)
                    if (ch != null && ch.size > 1 && ch.first() != 0.0) {
                        val pc = (ch.last() - ch.first()) / ch.first() * 100
                        Text(pctFmt(pc) + " no período", color = plColor(pc))
                    } else {
                        Text(pctFmt(coin.change24h) + " em 24h", color = plColor(coin.change24h))
                    }
                }
                item {
                    Box(Modifier.fillMaxWidth().height(200.dp), contentAlignment = Alignment.Center) {
                        val ch = chart?.let { c -> if (c.size > 1) c.dropLast(1) + coin.price else c }
                        when {
                            ch != null -> LineChart(ch, Modifier.fillMaxSize()) { sel = it }
                            failed -> Text("Não foi possível carregar o gráfico.", color = muted)
                            else -> CircularProgressIndicator()
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        Ranges.forEachIndexed { i, r ->
                            FilterChip(selected = rangeIdx == i, onClick = { rangeIdx = i }, label = { Text(r.label) })
                        }
                    }
                }
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Button(onClick = { sheet = true }, modifier = Modifier.weight(1f)) { Text("Comprar") }
                        OutlinedButton(onClick = { sheet = false }, enabled = holding != null, modifier = Modifier.weight(1f)) { Text("Vender") }
                    }
                }
                if (holding != null) {
                    item {
                        val value = holding.qty * coin.price
                        val pl = value - holding.costUsd
                        val pct = if (holding.costUsd > 0) pl / holding.costUsd * 100 else 0.0
                        Panel {
                            Text("Sua posição", fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(8.dp))
                            InfoRow("Quantidade", qtyFmt(holding.qty) + " " + coin.symbol)
                            InfoRow("Valor atual", vm.money(value))
                            InfoRow("Preço médio", vm.money(holding.costUsd / holding.qty))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Lucro / prejuízo", color = muted)
                                Text(vm.money(pl, true) + " (" + pctFmt(pct) + ")", color = plColor(pl))
                            }
                        }
                    }
                }
                item {
                    Panel {
                        Text("Sobre", fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(8.dp))
                        InfoRow("Símbolo", coin.symbol)
                        InfoRow("Valor de mercado", if (coin.marketCap > 0) vm.money(coin.marketCap) else "—")
                        InfoRow("Saldo disponível", vm.money(vm.cash))
                    }
                }
                item { Spacer(Modifier.height(24.dp)) }
            }
        }
    }

    if (coin != null) {
        sheet?.let { buy -> TradeSheet(vm, coin, buy) { sheet = null } }
        if (alertOpen) AlertDialogForm(vm, coin) { alertOpen = false }
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TradeSheet(vm: AppViewModel, coin: Coin, buy: Boolean, onDismiss: () -> Unit) {
    val holding = vm.holdings.find { it.coinId == coin.id }
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    var text by remember { mutableStateOf("") }
    val v = text.replace(',', '.').toDoubleOrNull() ?: 0.0
    val sym = if (vm.currency == "BRL") "R$" else "US$"

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 32.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text((if (buy) "Comprar " else "Vender ") + coin.name, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            Text("Preço: " + vm.money(coin.price), color = muted)
            OutlinedTextField(
                value = text, onValueChange = { text = it }, singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                label = { Text(if (buy) "Valor em $sym" else "Quantidade de " + coin.symbol) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(0.25 to "25%", 0.5 to "50%", 0.75 to "75%", 1.0 to "Máx").forEach { (p, t) ->
                    OutlinedButton(
                        onClick = {
                            text = if (buy) String.format(Locale.US, "%.2f", vm.fromUsd(vm.cash) * p - if (p == 1.0) 0.005 else 0.0)
                            else qtyFmt((holding?.qty ?: 0.0) * p)
                        },
                        contentPadding = PaddingValues(horizontal = 4.dp),
                        modifier = Modifier.weight(1f)
                    ) { Text(t) }
                }
            }
            if (buy) {
                Text("Disponível: " + vm.money(vm.cash), color = muted)
                Text("Você recebe ≈ " + qtyFmt(vm.toUsd(v) / coin.price) + " " + coin.symbol)
            } else {
                Text("Disponível: " + qtyFmt(holding?.qty ?: 0.0) + " " + coin.symbol, color = muted)
                Text("Você recebe ≈ " + vm.money(v * coin.price))
            }
            Button(
                onClick = {
                    val ok = if (buy) vm.buy(coin, vm.toUsd(v).coerceAtMost(vm.cash)) else vm.sell(coin, v)
                    if (ok) onDismiss()
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (buy) "Confirmar compra (fictícia)" else "Confirmar venda (fictícia)") }
        }
    }
}

@Composable
fun AlertDialogForm(vm: AppViewModel, coin: Coin, onDismiss: () -> Unit) {
    var target by remember { mutableStateOf("") }
    var above by remember { mutableStateOf(true) }
    val t = target.replace(',', '.').toDoubleOrNull() ?: 0.0
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Alerta de preço · " + coin.symbol) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Preço atual: US$ " + String.format(Locale.US, "%,.2f", coin.price))
                OutlinedTextField(
                    value = target, onValueChange = { target = it }, singleLine = true,
                    label = { Text("Preço alvo (US$)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = above, onClick = { above = true }, label = { Text("Subir acima") })
                    FilterChip(selected = !above, onClick = { above = false }, label = { Text("Cair abaixo") })
                }
                Text("A verificação roda em segundo plano, aproximadamente a cada 15 minutos.", fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        confirmButton = {
            TextButton(enabled = t > 0, onClick = { vm.addAlert(coin, t, above); onDismiss() }) { Text("Criar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
