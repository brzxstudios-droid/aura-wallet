package com.example.aurora

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun AuroraApp(vm: AppViewModel, onBiometric: (() -> Unit) -> Unit) {
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(vm.message) {
        vm.message?.let {
            snack.showSnackbar(it)
            vm.message = null
        }
    }
    if (!vm.unlocked) {
        LockScreen(vm, onBiometric)
        return
    }
    BackHandler(enabled = vm.stack.isNotEmpty()) { vm.pop() }
    BackHandler(enabled = vm.stack.isEmpty() && vm.tab != 0) { vm.tab = 0 }
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            AnimatedVisibility(
                visible = vm.stack.isEmpty(),
                enter = slideInVertically(tween(250)) { it } + fadeIn(tween(250)),
                exit = slideOutVertically(tween(200)) { it } + fadeOut(tween(150))
            ) { BottomBar(vm) }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            AnimatedContent(
                targetState = vm.stack,
                transitionSpec = {
                    if (targetState.size >= initialState.size) {
                        (slideInHorizontally(tween(280)) { it / 5 } + fadeIn(tween(280))) togetherWith
                            (slideOutHorizontally(tween(280)) { -it / 8 } + fadeOut(tween(160)))
                    } else {
                        (slideInHorizontally(tween(280)) { -it / 8 } + fadeIn(tween(280))) togetherWith
                            (slideOutHorizontally(tween(280)) { it / 5 } + fadeOut(tween(160)))
                    }
                },
                label = "route"
            ) { st ->
                when (val r = st.lastOrNull()) {
                    is Route.Detail -> DetailScreen(vm, r.id)
                    Route.Send -> SendScreen(vm)
                    Route.Receive -> ReceiveScreen(vm)
                    Route.Alerts -> AlertsScreen(vm)
                    Route.Settings -> SettingsScreen(vm)
                    null -> TabContent(vm)
                }
            }
        }
    }
}

@Composable
fun TabContent(vm: AppViewModel) {
    AnimatedContent(
        targetState = vm.tab,
        transitionSpec = {
            val dir = if (targetState > initialState) 1 else -1
            (slideInHorizontally(tween(260)) { dir * it / 6 } + fadeIn(tween(260))) togetherWith
                (slideOutHorizontally(tween(200)) { -dir * it / 6 } + fadeOut(tween(160)))
        },
        label = "tab"
    ) { t ->
        when (t) {
            0 -> HomeScreen(vm)
            1 -> MarketScreen(vm)
            2 -> WalletScreen(vm)
            3 -> HistoryScreen(vm)
            else -> ProfileScreen(vm)
        }
    }
}

@Composable
fun BottomBar(vm: AppViewModel) {
    val items = listOf(
        Icons.Filled.Home to "Início",
        Icons.Filled.BarChart to "Mercado",
        Icons.Filled.AccountBalanceWallet to "Carteira",
        Icons.Filled.History to "Histórico",
        Icons.Filled.Person to "Perfil"
    )
    Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(top = 4.dp)) {
        items.forEachIndexed { i, (icon, label) ->
            NavItem(icon, label, vm.tab == i, Modifier.weight(1f)) { vm.tab = i }
        }
    }
}

@Composable
fun NavItem(icon: ImageVector, label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val color by animateColorAsState(
        if (selected) MaterialTheme.colorScheme.onBackground else muted, tween(200), label = "navc"
    )
    val scale by animateFloatAsState(
        if (selected) 1.12f else 1f, spring(dampingRatio = 0.55f, stiffness = 400f), label = "navs"
    )
    val bar by animateDpAsState(if (selected) 24.dp else 0.dp, tween(220), label = "navb")
    Column(
        modifier.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onClick() }
            .padding(top = 6.dp, bottom = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, label, tint = color, modifier = Modifier.size(26.dp).scale(scale))
        Text(label, fontSize = 11.sp, color = color, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
        Spacer(Modifier.height(4.dp))
        Box(Modifier.height(3.dp).width(bar).clip(RoundedCornerShape(2.dp)).background(Accent))
    }
}

@Composable
fun LockScreen(vm: AppViewModel, onBiometric: (() -> Unit) -> Unit) {
    var pin by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { if (vm.biometric) onBiometric { vm.unlocked = true } }
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            Modifier.fillMaxSize().padding(32.dp),
            verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(Icons.Filled.Lock, null, tint = Accent, modifier = Modifier.size(48.dp))
            Spacer(Modifier.height(16.dp))
            Text("Aurora Wallet", style = MaterialTheme.typography.headlineSmall)
            Text("Digite seu PIN", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(24.dp))
            OutlinedTextField(
                value = pin,
                onValueChange = { v ->
                    if (v.length <= 8 && v.all { it.isDigit() }) {
                        pin = v
                        wrong = false
                        vm.tryUnlock(v)
                    }
                },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                isError = wrong,
                supportingText = { if (wrong) Text("PIN incorreto") }
            )
            Spacer(Modifier.height(12.dp))
            Button(onClick = { if (!vm.tryUnlock(pin)) wrong = true }) { Text("Desbloquear") }
            if (vm.biometric) {
                TextButton(onClick = { onBiometric { vm.unlocked = true } }) { Text("Usar digital") }
            }
        }
    }
}
