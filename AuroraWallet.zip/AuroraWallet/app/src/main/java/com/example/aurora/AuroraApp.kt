package com.example.aurora

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp

@Composable
fun AuroraApp(vm: AppViewModel, onBiometric: (() -> Unit) -> Unit) {
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(vm.message) {
        vm.message?.let {
            snack.showSnackbar(it)
            vm.message = null
        }
    }
    if (!vm.unlocked) {
        LockScreen(vm, onBiometric)
        return
    }
    BackHandler(enabled = vm.stack.isNotEmpty()) { vm.pop() }
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            if (vm.stack.isEmpty()) {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                    listOf(
                        Icons.Filled.Home to "Início",
                        Icons.Filled.ShowChart to "Mercado",
                        Icons.Filled.History to "Histórico",
                        Icons.Filled.Settings to "Ajustes"
                    ).forEachIndexed { i, (icon, label) ->
                        NavigationBarItem(
                            selected = vm.tab == i, onClick = { vm.tab = i },
                            icon = { Icon(icon, label) }, label = { Text(label) }
                        )
                    }
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            AnimatedContent(
                targetState = vm.stack.lastOrNull(),
                transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(140)) },
                label = "route"
            ) { r ->
                when (r) {
                    is Route.Detail -> DetailScreen(vm, r.id)
                    Route.Send -> SendScreen(vm)
                    Route.Receive -> ReceiveScreen(vm)
                    Route.Alerts -> AlertsScreen(vm)
                    null -> Crossfade(vm.tab, label = "tab") { t ->
                        when (t) {
                            0 -> HomeScreen(vm)
                            1 -> MarketScreen(vm)
                            2 -> HistoryScreen(vm)
                            else -> SettingsScreen(vm)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LockScreen(vm: AppViewModel, onBiometric: (() -> Unit) -> Unit) {
    var pin by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { if (vm.biometric) onBiometric { vm.unlocked = true } }
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            Modifier.fillMaxSize().padding(32.dp),
            verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(Icons.Filled.Lock, null, tint = Accent, modifier = Modifier.size(48.dp))
            Spacer(Modifier.height(16.dp))
            Text("Aurora Wallet", style = MaterialTheme.typography.headlineSmall)
            Text("Digite seu PIN", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(24.dp))
            OutlinedTextField(
                value = pin,
                onValueChange = { v ->
                    if (v.length <= 8 && v.all { it.isDigit() }) {
                        pin = v
                        wrong = false
                        vm.tryUnlock(v)
                    }
                },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                isError = wrong,
                supportingText = { if (wrong) Text("PIN incorreto") }
            )
            Spacer(Modifier.height(12.dp))
            Button(onClick = { if (!vm.tryUnlock(pin)) wrong = true }) { Text("Desbloquear") }
            if (vm.biometric) {
                TextButton(onClick = { onBiometric { vm.unlocked = true } }) { Text("Usar digital") }
            }
        }
    }
}
