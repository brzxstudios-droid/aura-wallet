package com.example.aurora

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

@Composable
fun AuroraApp() {
    var tab by remember { mutableIntStateOf(0) }
    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Card) {
                listOf(Icons.Filled.Home to "Início", Icons.Filled.SwapHoriz to "Trocar", Icons.Filled.Settings to "Ajustes")
                    .forEachIndexed { i, (icon, label) ->
                        NavigationBarItem(
                            selected = tab == i, onClick = { tab = i },
                            icon = { Icon(icon, label) }, label = { Text(label) }
                        )
                    }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> HomeScreen()
                else -> Placeholder(if (tab == 1) "Trocar" else "Ajustes")
            }
        }
    }
}

@Composable
fun HomeScreen() {
    val total = demoAssets.sumOf { it.value }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Spacer(Modifier.height(24.dp))
            Text("Saldo total", color = Muted, fontSize = 14.sp)
            Text("$" + String.format(Locale.US, "%,.2f", total), color = androidx.compose.ui.graphics.Color.White,
                fontSize = 38.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                ActionButton(Icons.Filled.ArrowUpward, "Enviar")
                ActionButton(Icons.Filled.ArrowDownward, "Receber")
                ActionButton(Icons.Filled.SwapHoriz, "Trocar")
                ActionButton(Icons.Filled.Add, "Adicionar")
            }
            Spacer(Modifier.height(12.dp))
            Text("Ativos", color = androidx.compose.ui.graphics.Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        }
        items(demoAssets) { AssetRow(it) }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
fun ActionButton(icon: ImageVector, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { }) {
        Box(Modifier.size(56.dp).clip(CircleShape).background(Card), contentAlignment = Alignment.Center) {
            Icon(icon, label, tint = Accent)
        }
        Spacer(Modifier.height(6.dp))
        Text(label, color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun AssetRow(a: Asset) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Card).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(40.dp).clip(CircleShape).background(Accent), contentAlignment = Alignment.Center) {
            Text(a.symbol.take(1), color = androidx.compose.ui.graphics.Color.White, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(a.name, color = androidx.compose.ui.graphics.Color.White, fontWeight = FontWeight.Medium)
            Text("${a.amount} ${a.symbol}", color = Muted, fontSize = 13.sp)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text("$" + String.format(Locale.US, "%,.2f", a.value), color = androidx.compose.ui.graphics.Color.White)
            Text(
                (if (a.change >= 0) "+" else "") + a.change + "%",
                color = if (a.change >= 0) Positive else Negative, fontSize = 13.sp
            )
        }
    }
}

@Composable
fun Placeholder(title: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(title, color = Muted, fontSize = 18.sp)
    }
}
