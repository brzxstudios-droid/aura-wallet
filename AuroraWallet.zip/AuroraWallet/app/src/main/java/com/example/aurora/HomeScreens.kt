package com.example.aurora

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

@Composable
fun HomeScreen(vm: AppViewModel) {
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val total = vm.totalValue()
    val pl = total - START_CASH
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(top = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Aurora Wallet", fontWeight = FontWeight.Bold, fontSize = 20.sp, modifier = Modifier.weight(1f))
                if (vm.loading) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                else IconButton(onClick = { vm.refresh() }) { Icon(Icons.Filled.Refresh, "Atualizar") }
            }
            Box(
                Modifier.clip(RoundedCornerShape(50)).background(Accent.copy(alpha = 0.18f))
                    .padding(horizontal = 12.dp, vertical = 4.dp)
            ) { Text("Modo demonstração · dinheiro fictício", color = Accent, fontSize = 12.sp) }
            vm.error?.let { Text(it, color = Negative, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)) }
        }
        item {
            Text("Saldo total", color = muted, fontSize = 14.sp)
            Text(vm.money(total), fontSize = 38.sp, fontWeight = FontWeight.Bold)
            Text(
                vm.money(pl, true) + " (" + pctFmt(pl / START_CASH * 100) + ") desde o início",
                color = plColor(pl), fontSize = 14.sp
            )
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                ActionButton(Icons.Filled.ArrowUpward, "Enviar") { vm.push(Route.Send) }
                ActionButton(Icons.Filled.ArrowDownward, "Receber") { vm.push(Route.Receive) }
                ActionButton(Icons.Filled.Add, "Comprar") { vm.tab = 1 }
                ActionButton(Icons.Filled.NotificationsActive, "Alertas") { vm.push(Route.Alerts) }
            }
        }
        item {
            val slices = buildList {
                vm.holdings.forEach { add(it.symbol to vm.holdingValue(it)) }
                add("Saldo" to vm.cash)
            }.filter { it.second > 0 }
            val sum = slices.sumOf { it.second }
            if (slices.isNotEmpty() && sum > 0) {
                Panel {
                    Text("Distribuição da carteira", fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(12.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        PieChart(slices.map { it.second.toFloat() }, Modifier.size(120.dp))
                        Spacer(Modifier.width(16.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            slices.forEachIndexed { i, (name, v) ->
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(Modifier.size(10.dp).clip(CircleShape).background(PieColors[i % PieColors.size]))
                                    Spacer(Modifier.width(8.dp))
                                    Text(name + "  " + String.format(Locale.US, "%.1f", v / sum * 100) + "%", fontSize = 13.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
        item {
            Panel {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Saldo disponível (fictício)", color = muted, fontSize = 13.sp)
                        Text(vm.money(vm.cash), fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                    }
                    Button(onClick = { vm.tab = 1 }) { Text("Comprar") }
                }
            }
        }
        item { Text("Meus ativos", fontSize = 18.sp, fontWeight = FontWeight.SemiBold) }
        if (vm.holdings.isEmpty()) {
            item { Text("Você ainda não tem ativos. Vá em Mercado e faça sua primeira compra de teste.", color = muted) }
        }
        items(vm.holdings) { h ->
            val value = vm.holdingValue(h)
            val hpl = value - h.costUsd
            val pct = if (h.costUsd > 0) hpl / h.costUsd * 100 else 0.0
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable { vm.openCoin(h.coinId) }
                    .background(MaterialTheme.colorScheme.surface).padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CoinLogo(h.image)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(h.name, fontWeight = FontWeight.Medium)
                    Text(qtyFmt(h.qty) + " " + h.symbol, color = muted, fontSize = 13.sp)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(vm.money(value))
                    Text(vm.money(hpl, true) + " (" + pctFmt(pct) + ")", color = plColor(hpl), fontSize = 12.sp)
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
fun MarketScreen(vm: AppViewModel) {
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableIntStateOf(0) }
    val base = vm.coins.filter {
        query.isBlank() || it.name.contains(query, true) || it.symbol.contains(query, true)
    }
    val list = when (filter) {
        1 -> base.filter { it.id in vm.favorites }
        2 -> base.sortedByDescending { it.change24h }.take(20)
        3 -> base.sortedBy { it.change24h }.take(20)
        else -> base
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(16.dp))
        Text("Mercado", fontWeight = FontWeight.Bold, fontSize = 22.sp)
        Text("Preços reais · compras com saldo fictício", color = muted, fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = query, onValueChange = { query = it }, singleLine = true,
            modifier = Modifier.fillMaxWidth(), placeholder = { Text("Buscar moeda") },
            leadingIcon = { Icon(Icons.Filled.Search, null) }
        )
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Todas", "Favoritas", "Maiores altas", "Maiores quedas").forEachIndexed { i, t ->
                FilterChip(selected = filter == i, onClick = { filter = i }, label = { Text(t) })
            }
        }
        if (vm.coins.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                if (vm.loading) CircularProgressIndicator() else Text(vm.error ?: "Sem dados ainda.", color = muted)
            }
        } else if (list.isEmpty()) {
            Text("Nada encontrado.", color = muted, modifier = Modifier.padding(top = 16.dp))
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(list) { c ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable { vm.openCoin(c.id) }
                            .background(MaterialTheme.colorScheme.surface).padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CoinLogo(c.image, 36.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(c.name, fontWeight = FontWeight.Medium, maxLines = 1)
                            Text(c.symbol, color = muted, fontSize = 12.sp)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(vm.money(c.price))
                            Text(pctFmt(c.change24h), color = plColor(c.change24h), fontSize = 12.sp)
                        }
                        IconButton(onClick = { vm.toggleFavorite(c.id) }) {
                            Icon(
                                if (c.id in vm.favorites) Icons.Filled.Star else Icons.Filled.StarBorder,
                                "Favoritar", tint = Accent
                            )
                        }
                    }
                }
                item { Spacer(Modifier.height(16.dp)) }
            }
        }
    }
}
