package com.example.aurora

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import java.util.Locale

@Composable
fun BalanceCard(vm: AppViewModel, shown: Double, pl: Double, running: Boolean, onInfo: () -> Unit) {
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val accent = Accent
    val surface = MaterialTheme.colorScheme.surface
    // O brilho pausa enquanto a lista rola, para manter a rolagem fluida
    val t = remember { Animatable(0f) }
    LaunchedEffect(running, vm.gradient) {
        if (running && vm.gradient) {
            while (true) {
                t.animateTo(1f, tween(8000, easing = LinearEasing))
                t.animateTo(0f, tween(8000, easing = LinearEasing))
            }
        }
    }
    val base = Modifier.fillMaxWidth()
    val card = if (vm.gradient) {
        base.clip(RoundedCornerShape(28.dp)).background(surface).drawBehind {
            drawRect(
                Brush.radialGradient(
                    listOf(accent.copy(alpha = 0.50f), accent.copy(alpha = 0.14f), Color.Transparent),
                    center = Offset(size.width * (0.15f + 0.5f * t.value), size.height * (0.2f + 0.4f * t.value)),
                    radius = size.width * 0.75f
                )
            )
            drawRect(
                Brush.radialGradient(
                    listOf(lerp(accent, Color.White, 0.4f).copy(alpha = 0.30f), Color.Transparent),
                    center = Offset(size.width * (0.85f - 0.5f * t.value), size.height * (0.9f - 0.4f * t.value)),
                    radius = size.width * 0.65f
                )
            )
        }
    } else base
    val text = vm.moneyH(shown)
    Box(card) {
        Column(
            Modifier.fillMaxWidth().padding(vertical = 26.dp, horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Saldo total", color = muted, fontSize = 14.sp)
                Spacer(Modifier.width(4.dp))
                Icon(Icons.Filled.Info, "Sobre o saldo", tint = muted, modifier = Modifier.size(15.dp).clickable { onInfo() })
            }
            Spacer(Modifier.height(4.dp))
            Text(
                text, fontSize = if (text.length > 11) 38.sp else 46.sp, fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center, maxLines = 1, softWrap = false
            )
            Spacer(Modifier.height(10.dp))
            Row(
                Modifier.clip(RoundedCornerShape(50)).background(plColor(pl).copy(alpha = 0.16f))
                    .padding(start = 6.dp, end = 12.dp, top = 3.dp, bottom = 3.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    if (pl >= 0) Icons.Filled.ArrowDropUp else Icons.Filled.ArrowDropDown, null,
                    tint = plColor(pl), modifier = Modifier.size(20.dp)
                )
                Text(
                    if (vm.hideBalance) "••••••" else vm.money(pl, true) + " (" + pctFmt(pl / START_CASH * 100) + ")",
                    color = plColor(pl), fontSize = 13.sp, fontWeight = FontWeight.Medium
                )
            }
        }
        Box(
            Modifier.align(Alignment.TopEnd).padding(10.dp).size(38.dp).clip(CircleShape)
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)).clickable { vm.toggleHide() },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                if (vm.hideBalance) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                "Ocultar saldo", modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
fun RangeChip(label: String, selected: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(
        if (selected) MaterialTheme.colorScheme.surfaceVariant else Color.Transparent, tween(200), label = "chipbg"
    )
    Box(
        Modifier.clip(RoundedCornerShape(50)).background(bg).clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(
            label, fontSize = 13.sp, fontWeight = FontWeight.Medium,
            color = if (selected) MaterialTheme.colorScheme.onBackground else MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun AssetRow(vm: AppViewModel, h: Holding, onClick: () -> Unit) {
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val ch = vm.coins.find { it.id == h.coinId }?.change24h
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable { onClick() }
            .background(MaterialTheme.colorScheme.surface).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        CoinLogo(h.image, 44.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(h.name, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Text(qtyFmt(h.qty) + " " + h.symbol, color = muted, fontSize = 13.sp, maxLines = 1)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(vm.moneyH(vm.holdingValue(h)), fontWeight = FontWeight.SemiBold)
            if (ch != null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        if (ch >= 0) Icons.Filled.ArrowDropUp else Icons.Filled.ArrowDropDown, null,
                        tint = plColor(ch), modifier = Modifier.size(18.dp)
                    )
                    Text(pctFmt(ch).removePrefix("+"), color = plColor(ch), fontSize = 12.sp)
                }
            }
        }
        Icon(Icons.Filled.ChevronRight, null, tint = muted)
    }
}

@Composable
fun HomeScreen(vm: AppViewModel) {
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val total = vm.totalValue()
    val pl = total - START_CASH
    val invested = vm.holdingsValue()
    val px = Modifier.padding(horizontal = 20.dp)

    val listState = rememberLazyListState()
    var intro by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        delay(1200)
        intro = false
    }

    // contagem animada do saldo
    val anim = remember { Animatable(0f) }
    var from by remember { mutableStateOf(0.0) }
    var to by remember { mutableStateOf(total) }
    LaunchedEffect(total) {
        from = from + (to - from) * anim.value
        to = total
        anim.snapTo(0f)
        anim.animateTo(1f, tween(700, easing = FastOutSlowInEasing))
    }

    // gráfico patrimonial real
    var range by remember { mutableIntStateOf(0) }
    var series by remember { mutableStateOf<List<Double>?>(null) }
    var sel by remember { mutableStateOf<Int?>(null) }
    LaunchedEffect(range, vm.txs.size) {
        try {
            series = vm.wealth(range)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
        }
    }

    var infoTotal by remember { mutableStateOf(false) }
    var infoAvail by remember { mutableStateOf(false) }

    LazyColumn(Modifier.fillMaxSize(), state = listState, verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Column(px) {
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    RoundIconButton(Icons.Filled.Settings, "Ajustes") { vm.push(Route.Settings) }
                    Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                        Row(
                            Modifier.clip(RoundedCornerShape(50)).clickable { /* escolher carteira: em breve */ }
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Carteira", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Icon(Icons.Filled.KeyboardArrowDown, "Escolher carteira")
                        }
                    }
                    if (vm.loading) {
                        Box(Modifier.size(44.dp), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                        }
                    } else {
                        RoundIconButton(Icons.Filled.Refresh, "Atualizar") { vm.refresh() }
                    }
                }
                vm.error?.let { Text(it, color = Negative, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)) }
            }
        }
        item {
            Box(px) {
                Appear(0, intro) {
                    BalanceCard(vm, from + (to - from) * anim.value, pl, !listState.isScrollInProgress) { infoTotal = true }
                }
            }
        }
        item {
            Appear(1, intro) {
                Column {
                    Row(px.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        Ranges.forEachIndexed { i, r -> RangeChip(r.label, range == i) { range = i } }
                    }
                    Box(Modifier.fillMaxWidth().height(150.dp), contentAlignment = Alignment.Center) {
                        val s = series
                        if (s != null && s.size > 1) {
                            val liveSeries = remember(s, total) { s.dropLast(1) + total }
                            LineChart(liveSeries, Modifier.fillMaxSize()) { sel = it }
                            sel?.let { i ->
                                liveSeries.getOrNull(i)?.let {
                                    Text(
                                        vm.moneyH(it), fontSize = 12.sp, color = muted,
                                        modifier = Modifier.align(Alignment.TopStart).padding(start = 20.dp)
                                    )
                                }
                            }
                        } else {
                            CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp)
                        }
                    }
                }
            }
        }
        item {
            Box(px) {
                Appear(2, intro) {
                    Row(Modifier.fillMaxWidth()) {
                        ActionButton(Icons.Filled.ArrowUpward, "Enviar", Modifier.weight(1f)) { vm.push(Route.Send) }
                        ActionButton(Icons.Filled.ArrowDownward, "Receber", Modifier.weight(1f)) { vm.push(Route.Receive) }
                        ActionButton(Icons.Filled.Add, "Comprar", Modifier.weight(1f), primary = true) { vm.tab = 1 }
                        ActionButton(Icons.Filled.NotificationsActive, "Alertas", Modifier.weight(1f)) { vm.push(Route.Alerts) }
                    }
                }
            }
        }
        item {
            val slices = buildList {
                vm.holdings.forEach { add(it.symbol to vm.holdingValue(it)) }
                add("Saldo" to vm.cash)
            }.filter { it.second > 0 }
            val sum = slices.sumOf { it.second }
            val colors = pieColors()
            var go by remember { mutableStateOf(false) }
            LaunchedEffect(Unit) { go = true }
            val pieP by animateFloatAsState(if (go) 1f else 0f, tween(1000), label = "pie")
            if (slices.isNotEmpty() && sum > 0) {
                Box(px) {
                    Appear(3, intro) {
                        Panel(Modifier.clip(RoundedCornerShape(16.dp)).clickable { vm.tab = 2 }) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.DonutLarge, null, tint = Accent, modifier = Modifier.size(22.dp))
                                Spacer(Modifier.width(10.dp))
                                Text("Distribuição da carteira", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                                Icon(Icons.Filled.ChevronRight, null, tint = muted)
                            }
                            Spacer(Modifier.height(12.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                PieChart(slices.map { it.second.toFloat() }, Modifier.size(118.dp), pieP)
                                Spacer(Modifier.width(16.dp))
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    slices.forEachIndexed { i, (name, v) ->
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Box(Modifier.size(10.dp).clip(CircleShape).background(colors[i % colors.size]))
                                            Spacer(Modifier.width(8.dp))
                                            Text(name, fontSize = 13.sp, maxLines = 1, modifier = Modifier.width(46.dp))
                                            Text(
                                                String.format(Locale.US, "%.1f", v / sum * 100) + "%",
                                                fontSize = 13.sp, color = muted, modifier = Modifier.width(48.dp)
                                            )
                                            Text(
                                                vm.moneyH(v), fontSize = 13.sp, textAlign = TextAlign.End,
                                                maxLines = 1, modifier = Modifier.weight(1f)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        item {
            Box(px) {
                Appear(4, intro) {
                    Panel {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Filled.AccountBalanceWallet, null, tint = muted, modifier = Modifier.size(15.dp))
                                    Spacer(Modifier.width(5.dp))
                                    Text("Disponível", color = muted, fontSize = 12.sp)
                                    Spacer(Modifier.width(4.dp))
                                    Icon(
                                        Icons.Filled.Info, "Sobre o saldo disponível", tint = muted,
                                        modifier = Modifier.size(13.dp).clickable { infoAvail = true }
                                    )
                                }
                                Text(vm.moneyH(vm.cash), fontWeight = FontWeight.SemiBold, fontSize = 16.sp, maxLines = 1)
                            }
                            Box(Modifier.width(1.dp).height(36.dp).background(muted.copy(alpha = 0.3f)))
                            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Filled.PieChart, null, tint = muted, modifier = Modifier.size(15.dp))
                                    Spacer(Modifier.width(5.dp))
                                    Text("Em ativos", color = muted, fontSize = 12.sp)
                                }
                                Text(vm.moneyH(invested), fontWeight = FontWeight.SemiBold, fontSize = 16.sp, maxLines = 1)
                            }
                            Button(onClick = { vm.tab = 1 }, contentPadding = PaddingValues(horizontal = 14.dp)) { Text("Comprar") }
                        }
                    }
                }
            }
        }
        item {
            Box(px) {
                Appear(5, intro) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("Meus ativos", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        if (vm.holdings.isNotEmpty()) {
                            Row(Modifier.clip(RoundedCornerShape(50)).clickable { vm.tab = 2 }.padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text("Ver todos", color = muted, fontSize = 14.sp)
                                Icon(Icons.Filled.ChevronRight, null, tint = muted, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        }
        if (vm.holdings.isEmpty()) {
            item {
                Text(
                    "Você ainda não tem ativos. Vá em Mercado e faça sua primeira compra de teste.",
                    color = muted, modifier = px
                )
            }
        }
        items(vm.holdings.take(5), key = { it.coinId }) { h ->
            Box(px) { AssetRow(vm, h) { vm.openCoin(h.coinId) } }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }

    if (infoTotal) AlertDialog(
        onDismissRequest = { infoTotal = false },
        confirmButton = { TextButton(onClick = { infoTotal = false }) { Text("Ok") } },
        title = { Text("Saldo total") },
        text = { Text("Soma do saldo disponível com o valor atual dos seus ativos, calculado com os preços reais do mercado. O saldo em si é fictício (modo demonstração).") }
    )
    if (infoAvail) AlertDialog(
        onDismissRequest = { infoAvail = false },
        confirmButton = { TextButton(onClick = { infoAvail = false }) { Text("Ok") } },
        title = { Text("Saldo disponível") },
        text = { Text("Dinheiro fictício que ainda não foi investido em moedas. É com ele que você faz novas compras.") }
    )
}

@Composable
fun MarketScreen(vm: AppViewModel) {
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableIntStateOf(0) }
    val base = vm.coins.filter {
        query.isBlank() || it.name.contains(query, true) || it.symbol.contains(query, true)
    }
    val list = when (filter) {
        1 -> base.filter { it.id in vm.favorites }
        2 -> base.sortedByDescending { it.change24h }.take(20)
        3 -> base.sortedBy { it.change24h }.take(20)
        else -> base
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(16.dp))
        Text("Mercado", fontWeight = FontWeight.Bold, fontSize = 22.sp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(8.dp).clip(CircleShape).background(if (vm.live) Positive else muted))
            Spacer(Modifier.width(6.dp))
            Text(
                if (vm.live) "Ao vivo · preços reais, atualizados a cada 3 s" else "Preços reais · última atualização salva",
                color = muted, fontSize = 12.sp
            )
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = query, onValueChange = { query = it }, singleLine = true,
            modifier = Modifier.fillMaxWidth(), placeholder = { Text("Buscar moeda") },
            leadingIcon = { Icon(Icons.Filled.Search, null) }
        )
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Todas", "Favoritas", "Maiores altas", "Maiores quedas").forEachIndexed { i, t ->
                FilterChip(selected = filter == i, onClick = { filter = i }, label = { Text(t) })
            }
        }
        if (vm.coins.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                if (vm.loading) CircularProgressIndicator() else Text(vm.error ?: "Sem dados ainda.", color = muted)
            }
        } else if (list.isEmpty()) {
            Text("Nada encontrado.", color = muted, modifier = Modifier.padding(top = 16.dp))
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(list, key = { it.id }) { c ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable { vm.openCoin(c.id) }
                            .background(MaterialTheme.colorScheme.surface).padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CoinLogo(c.image, 36.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(c.name, fontWeight = FontWeight.Medium, maxLines = 1)
                            Text(c.symbol, color = muted, fontSize = 12.sp)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(vm.money(c.price))
                            Text(pctFmt(c.change24h), color = plColor(c.change24h), fontSize = 12.sp)
                        }
                        IconButton(onClick = { vm.toggleFavorite(c.id) }) {
                            Icon(
                                if (c.id in vm.favorites) Icons.Filled.Star else Icons.Filled.StarBorder,
                                "Favoritar", tint = Accent
                            )
                        }
                    }
                }
                item { Spacer(Modifier.height(16.dp)) }
            }
        }
    }
}
