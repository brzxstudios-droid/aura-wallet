package com.example.aurora

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle

// Envia avisos para o app separado "Aurora Avisos", que mostra a notificação.
object Notifier {
    const val PKG = "com.example.aurora.notify"
    private const val AUTH = "com.example.aurora.notify.provider"
    private const val RECEIVER = "com.example.aurora.notify.NotifyReceiver"
    private const val ACTION = "com.example.aurora.notify.SHOW"

    // Resultados: 1 entregue, 2 sem permissão no Aurora Avisos, 0 enviado sem confirmação,
    // -1 Aurora Avisos não instalado, -2 falhou
    fun isInstalled(ctx: Context): Boolean = try {
        ctx.packageManager.getPackageInfo(PKG, 0)
        true
    } catch (e: Exception) {
        false
    }

    /** Chame fora da thread principal. */
    fun send(ctx: Context, title: String, text: String): Int {
        if (!isInstalled(ctx)) return -1
        val time = System.currentTimeMillis()
        // 1) Provider do Aurora Avisos: acorda o app mesmo parado e devolve a confirmação
        try {
            val b = Bundle()
            b.putString("title", title)
            b.putString("text", text)
            b.putLong("time", time)
            val r = ctx.contentResolver.call(Uri.parse("content://$AUTH"), "show", null, b)
            val code = r?.getInt("result", 0) ?: 0
            if (code == 1 || code == 2) return code
        } catch (e: Exception) {
        }
        // 2) Reserva: broadcast explícito (versões antigas do Aurora Avisos)
        return try {
            val i = Intent(ACTION).apply {
                component = ComponentName(PKG, RECEIVER)
                addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES)
                putExtra("title", title)
                putExtra("text", text)
                putExtra("time", time)
            }
            ctx.sendBroadcast(i)
            0
        } catch (e: Exception) {
            -2
        }
    }
}
