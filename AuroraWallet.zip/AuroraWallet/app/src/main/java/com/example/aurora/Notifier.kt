package com.example.aurora

import android.content.ComponentName
import android.content.Context
import android.content.Intent

// Envia avisos para o app separado "Aurora Avisos", que mostra a notificação.
object Notifier {
    const val PKG = "com.example.aurora.notify"
    private const val RECEIVER = "com.example.aurora.notify.NotifyReceiver"
    private const val ACTION = "com.example.aurora.notify.SHOW"

    fun isInstalled(ctx: Context): Boolean = try {
        ctx.packageManager.getPackageInfo(PKG, 0)
        true
    } catch (e: Exception) {
        false
    }

    /** Retorna false se o Aurora Avisos não estiver instalado. */
    fun send(ctx: Context, title: String, text: String): Boolean {
        if (!isInstalled(ctx)) return false
        val i = Intent(ACTION).apply {
            component = ComponentName(PKG, RECEIVER)
            addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES)
            putExtra("title", title)
            putExtra("text", text)
            putExtra("time", System.currentTimeMillis())
        }
        ctx.sendBroadcast(i)
        return true
    }
}
