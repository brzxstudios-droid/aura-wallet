package com.example.aurora

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

// Preços ao vivo, gráficos e câmbio: API pública da Binance (sem chave, leve e rápida).
// Nomes, logos e valor de mercado: CoinGecko (consultado pouco, com cache).
object Api {
    private const val GECKO = "https://api.coingecko.com/api/v3"
    private val hosts = listOf("https://data-api.binance.vision", "https://api.binance.com")
    @Volatile private var hostIdx = 0

    private fun get(url: String, timeoutMs: Int = 10000): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = timeoutMs
        c.readTimeout = timeoutMs + 4000
        c.setRequestProperty("Accept", "application/json")
        try {
            if (c.responseCode != 200) throw RuntimeException("HTTP " + c.responseCode)
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    // Tenta o espelho público da Binance e, se falhar, o endereço principal.
    private fun bget(path: String): String {
        var last: Exception? = null
        for (k in hosts.indices) {
            val i = (hostIdx + k) % hosts.size
            try {
                val r = get(hosts[i] + path, 6000)
                hostIdx = i
                return r
            } catch (e: Exception) {
                last = e
            }
        }
        throw last ?: RuntimeException("Binance indisponível")
    }

    private fun parsePrices(json: String): Map<String, Double> {
        val a = JSONArray(json)
        val m = HashMap<String, Double>(a.length() * 2)
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val p = o.optString("price").toDoubleOrNull()
            if (p != null) m[o.getString("symbol")] = p
        }
        return m
    }

    private fun enc(symbols: List<String>): String =
        URLEncoder.encode(JSONArray(symbols).toString(), "UTF-8")

    /** Todos os pares da Binance com o preço atual (também diz quais pares existem). */
    suspend fun binanceAll(): Map<String, Double> = withContext(Dispatchers.IO) {
        parsePrices(bget("/api/v3/ticker/price"))
    }

    /** Preço atual de uma lista de pares (rápido, ideal para atualizar a cada poucos segundos). */
    suspend fun binancePrices(symbols: List<String>): Map<String, Double> = withContext(Dispatchers.IO) {
        if (symbols.isEmpty()) emptyMap() else parsePrices(bget("/api/v3/ticker/price?symbols=" + enc(symbols)))
    }

    /** Preço e variação de 24h (em %) por par. */
    suspend fun binance24h(symbols: List<String>): Map<String, Pair<Double, Double>> = withContext(Dispatchers.IO) {
        val out = HashMap<String, Pair<Double, Double>>()
        if (symbols.isNotEmpty()) {
            val a = JSONArray(bget("/api/v3/ticker/24hr?symbols=" + enc(symbols)))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val p = o.optString("lastPrice").toDoubleOrNull()
                val c = o.optString("priceChangePercent").toDoubleOrNull()
                if (p != null && c != null) out[o.getString("symbol")] = p to c
            }
        }
        out
    }

    /** Velas da Binance: pares (horário em ms, preço de fechamento). */
    suspend fun klines(symbol: String, interval: String, limit: Int): List<Pair<Long, Double>> =
        withContext(Dispatchers.IO) {
            val a = JSONArray(bget("/api/v3/klines?symbol=$symbol&interval=$interval&limit=$limit"))
            (0 until a.length()).map {
                val k = a.getJSONArray(it)
                k.getLong(0) to k.getString(4).toDouble()
            }
        }

    // ---------- CoinGecko (metadados e reserva) ----------
    suspend fun markets(): List<Coin> = withContext(Dispatchers.IO) {
        val arr = JSONArray(
            get("$GECKO/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=100&page=1&sparkline=false&price_change_percentage=24h")
        )
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Coin(
                o.getString("id"),
                o.getString("symbol").uppercase(),
                o.getString("name"),
                o.optString("image"),
                o.optDouble("current_price", 0.0).safe(),
                o.optDouble("price_change_percentage_24h", 0.0).safe(),
                o.optDouble("market_cap", 0.0).safe()
            )
        }
    }

    suspend fun geckoChart(id: String, days: Int): List<Pair<Long, Double>> = withContext(Dispatchers.IO) {
        val p = JSONObject(get("$GECKO/coins/$id/market_chart?vs_currency=usd&days=$days")).getJSONArray("prices")
        (0 until p.length()).map { p.getJSONArray(it).let { r -> r.getLong(0) to r.getDouble(1) } }
    }

    suspend fun usdBrl(): Double = withContext(Dispatchers.IO) {
        JSONObject(get("$GECKO/simple/price?ids=tether&vs_currencies=brl"))
            .getJSONObject("tether").getDouble("brl")
    }

    private val FALLBACK = listOf(
        Triple("bitcoin", "BTC", "Bitcoin"), Triple("ethereum", "ETH", "Ethereum"),
        Triple("tether", "USDT", "Tether"), Triple("binancecoin", "BNB", "BNB"),
        Triple("solana", "SOL", "Solana"), Triple("ripple", "XRP", "XRP"),
        Triple("usd-coin", "USDC", "USDC"), Triple("cardano", "ADA", "Cardano"),
        Triple("dogecoin", "DOGE", "Dogecoin"), Triple("tron", "TRX", "TRON"),
        Triple("avalanche-2", "AVAX", "Avalanche"), Triple("chainlink", "LINK", "Chainlink"),
        Triple("polkadot", "DOT", "Polkadot"), Triple("litecoin", "LTC", "Litecoin"),
        Triple("shiba-inu", "SHIB", "Shiba Inu"), Triple("stellar", "XLM", "Stellar"),
        Triple("bitcoin-cash", "BCH", "Bitcoin Cash"), Triple("monero", "XMR", "Monero")
    )

    /** Lista mínima usada só quando a CoinGecko falha e não há cache. Os preços vêm da Binance. */
    fun fallbackCoins(): List<Coin> = FALLBACK.map { (id, s, n) ->
        Coin(
            id, s, n, "https://assets.coincap.io/assets/icons/" + s.lowercase() + "@2x.png",
            if (s == "USDT" || s == "USDC") 1.0 else 0.0, 0.0, 0.0
        )
    }
}
