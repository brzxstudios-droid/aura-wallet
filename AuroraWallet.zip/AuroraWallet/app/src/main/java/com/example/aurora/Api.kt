package com.example.aurora

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

// API pública e gratuita da CoinGecko (sem chave). Possui limite de requisições.
object Api {
    private const val BASE = "https://api.coingecko.com/api/v3"

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 15000
        c.setRequestProperty("Accept", "application/json")
        try {
            if (c.responseCode != 200) throw RuntimeException("HTTP " + c.responseCode)
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    suspend fun markets(): List<Coin> = withContext(Dispatchers.IO) {
        val arr = JSONArray(
            get("$BASE/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=100&page=1&sparkline=false&price_change_percentage=24h")
        )
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Coin(
                o.getString("id"),
                o.getString("symbol").uppercase(),
                o.getString("name"),
                o.optString("image"),
                o.optDouble("current_price", 0.0).safe(),
                o.optDouble("price_change_percentage_24h", 0.0).safe(),
                o.optDouble("market_cap", 0.0).safe()
            )
        }
    }

    suspend fun chart(id: String, days: Int): List<Double> = withContext(Dispatchers.IO) {
        val o = JSONObject(get("$BASE/coins/$id/market_chart?vs_currency=usd&days=$days"))
        val p = o.getJSONArray("prices")
        (0 until p.length()).map { p.getJSONArray(it).getDouble(1) }
    }

    // Cotação do dólar em reais (usa o USDT como referência do dólar)
    suspend fun usdBrl(): Double = withContext(Dispatchers.IO) {
        JSONObject(get("$BASE/simple/price?ids=tether&vs_currencies=brl"))
            .getJSONObject("tether").getDouble("brl")
    }
}
